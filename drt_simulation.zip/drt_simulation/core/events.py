"""
Event topics enumeration for DRT simulation.

This module defines all event topics used throughout the simulation
as an enumeration class to prevent hardcoded strings and improve
maintainability.
"""

from enum import Enum


class EventTopic(str, Enum):
    """
    Enumeration of all event topics in the DRT simulation.

    Inherits from both str and Enum to allow direct string comparison and
    usage with the EventBroker implementation.
    """

    REQUEST_CREATED = "REQUEST_CREATED"
    """Published when a new request is created."""

    PASSENGER_ARRIVED_AT_STOP = "PASSENGER_ARRIVED_AT_STOP"
    """Published when a passenger arrives at their assigned stop."""

    PASSENGER_BOARDED = "PASSENGER_BOARDED"
    """Published when a passenger successfully boards a vehicle."""

    PASSENGER_ALIGHTED = "PASSENGER_ALIGHTED"
    """Published when a passenger alights (exits) a vehicle."""

    REQUEST_CANCELLED = "REQUEST_CANCELLED"
    """Published when a request is cancelled."""
