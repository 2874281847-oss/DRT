# /core/engine.py

class SimulationEngine:
    """
    Time-driven simulation engine.

    Responsible for maintaining the global simulation clock and invoking
    registered modules in a deterministic order at every time step.
    """

    def __init__(self, config: dict,
                 physics_services: list,
                 logic_services: list,
                 controllers: list,
                 interfaces: list):

        # 1. 从配置中获取仿真参数
        self.current_time: int = config['start_time']
        self.end_time: int = config['end_time']
        self.time_step: int = config['time_step']  # e.g., 1 (秒)
        # 2. 存储所有已实例化的模块
        # 将 Services 显式拆分为物理服务 (physics) 与 业务逻辑服务 (logic)
        self.physics_services = physics_services
        self.logic_services = logic_services
        self.controllers = controllers   # Controllers (decision layer)
        self.interfaces = interfaces     # Data interfaces

    def _step(self):
        """
        Execute a single simulation time step.

        Core ordering to preserve correctness:
        1. Physics services update (vehicle movement, kinematics)
        2. Logic services update (state machines, arrivals, boarding/alighting)
        3. Controllers execute decisions based on the updated state
        4. Interfaces record or export the final state of this time step
        """

        # 1. Phase 1 - Physics services (move vehicles, update kinematics)
        for service in self.physics_services:
            if hasattr(service, 'update'):
                service.update(self.current_time, self.time_step)

        # 2. Phase 2 - Logic services (state machines, arrival checks, boarding/alighting)
        for service in self.logic_services:
            if hasattr(service, 'update'):
                service.update(self.current_time, self.time_step)

        # 3. Controllers make decisions based on the latest state
        #    Controllers should read from services and issue commands via service APIs
        for controller in self.controllers:
            if hasattr(controller, 'update'):
                controller.update(self.current_time, self.time_step)

        # 4. 输出数据 (Interfaces)
        #    (接口读取 Services 的最终状态, 用于日志或可视化)
        # For backwards compatibility, supply interfaces with the combined services list
        combined_services = list(self.physics_services) + \
            list(self.logic_services)
        for interface in self.interfaces:
            if hasattr(interface, 'update'):
                interface.update(self.current_time,
                                 self.time_step, combined_services)

    def run(self):
        """ 启动仿真主循环 """
        print(
            f"--- 仿真开始: T={self.current_time} to T={self.end_time} (步长: {self.time_step}s) ---")

        while self.current_time < self.end_time:

            # 执行单步逻辑
            self._step()

            # 推进时钟
            self.current_time += self.time_step

        print(f"--- 仿真结束: T={self.current_time} ---")
