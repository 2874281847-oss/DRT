from typing import Any, Callable, Dict, List


class EventBroker:
    """Lightweight publish/subscribe event broker.

    - Maintains a mapping of topic -> list of handlers
    - publish synchronously invokes all handlers registered to a topic
    """

    def __init__(self) -> None:
        self._subscribers: Dict[str, List[Callable[[Any], None]]] = {}

    def subscribe(self, topic: str, handler: Callable[[Any], None]) -> None:
        """Subscribe a handler to a topic.

        When the topic is published, handler(data) will be invoked.
        """
        if topic not in self._subscribers:
            self._subscribers[topic] = []
        self._subscribers[topic].append(handler)

    def publish(self, topic: str, data: Any) -> None:
        """Publish data to all subscribers of the topic.

        Exceptions raised by handlers are caught and logged so that one failing
        handler does not prevent other handlers from executing.
        """
        handlers = list(self._subscribers.get(topic, []))
        if not handlers:
            return

        for h in handlers:
            try:
                h(data)
            except Exception as e:
                # 简单记录错误, 避免因为一个 handler 崩溃而中断其它 handler
                print(f"[EventBroker] handler for topic '{topic}' raised: {e}")
