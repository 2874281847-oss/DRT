# /main.py
import argparse
import yaml
from pathlib import Path
import os
import random
import numpy as np
from typing import Optional
from pydantic import BaseModel, field_validator, ConfigDict

from core.engine import SimulationEngine
from analytics.data_logger import SimulationDataLogger
from services.road_network_service import RoadNetworkService
from services.stop_service import StopService
from services.demand_generator import DemandGenerator
from services.demand_state_service import DemandStateService
from services.vehicle_state_service import VehicleStateService
from services.vehicle_physics_service import VehiclePhysicsService
from services.stop_operation_service import StopOperationService
from services.fleet_loader import FleetLoader
from controllers.d2d_controller import D2DController
from controllers.fixed_route_controller import FixedRouteController
from strategies.nearest_neighbor import NearestNeighborStrategy
from strategies.rl_strategy import RLStrategy
from core.event_broker import EventBroker


# ============================================================================
# Pydantic v2 Configuration Models
# ============================================================================

class SimulationConfig(BaseModel):
    """
    Simulation parameters configuration.

    Attributes:
        start_time: Simulation start time (absolute seconds).
        end_time: Simulation end time (absolute seconds).
        time_step: Time step duration in seconds used by the engine loop.
        start_time_of_day_seconds: Offset in seconds for the start-of-day used by
            demand generators and time-of-day calculations.
        timeslice_duration_seconds: Duration in seconds for demand timeslices.
    """
    start_time: int
    end_time: int
    time_step: int
    start_time_of_day_seconds: int
    timeslice_duration_seconds: int

    # Pydantic v2: use model_config with ConfigDict instead of class-based Config
    model_config = ConfigDict(validate_assignment=True)


class DataPaths(BaseModel):
    """
    Paths to scenario data files (relative to the scenario file directory).

    Attributes:
        network: Path to network/map file.
        zones: Path to zones CSV defining service areas.
        od_matrix: Path to OD matrix CSV used by the demand generator.
        fleet: Path to fleet CSV describing vehicles.
        stops: Path to stops CSV for fixed-route services.
        d2d_modes_db: Optional YAML describing door-to-door mode definitions.
        fixed_routes_db: Optional YAML describing fixed-route mode definitions.
    """
    network: str
    zones: str
    od_matrix: str
    fleet: str
    stops: str
    d2d_modes_db: Optional[str] = None
    fixed_routes_db: Optional[str] = None

    # Pydantic v2: use model_config with ConfigDict instead of class-based Config
    model_config = ConfigDict(validate_assignment=True)


class ScenarioConfig(BaseModel):
    """
    Complete scenario configuration model.

    This model nests the simulation parameter configuration and the data paths
    configuration. It is intended to be validated against the YAML scenario
    file provided by the user.
    """
    simulation: SimulationConfig
    data_paths: DataPaths

    # Pydantic v2: use model_config with ConfigDict instead of class-based Config
    model_config = ConfigDict(validate_assignment=True)


# ============================================================================
# Configuration Manager
# ============================================================================

class ConfigurationManager:
    def __init__(self, scenario_file_path: Path):
        self.scenario_file = scenario_file_path.resolve()
        # scenario 文件所在目录, e.g. /Users/samuel/Desktop/research_desktop/drt_simulation/config/minimal
        self.scenario_dir = self.scenario_file.parent

        print(f"--- Loading Scenario: {self.scenario_file.name} ---")
        if not self.scenario_file.exists():
            raise FileNotFoundError(f"主场景文件未找到: {self.scenario_file}")

        with open(self.scenario_file, 'r') as f:
            yaml_dict = yaml.safe_load(f)

        # 使用 Pydantic 验证和解析配置
        try:
            self.config: ScenarioConfig = ScenarioConfig.model_validate(
                yaml_dict)
        except Exception as e:
            raise ValueError(f"配置文件验证失败: {e}")

        # 用于存储所有 *已定义* 模式的"数据库"
        self.mode_definitions = {
            'd2d': {},
            'fixed_route': {},
            'semi_flex': {}
        }

    def _get_data_path(self, key: str) -> Path:
        """
        Build an absolute Path from a key in the scenario data_paths.

        Args:
            key: Attribute name on the DataPaths model (e.g. 'zones', 'fleet').

        Returns:
            A resolved pathlib.Path for the requested data file.

        Raises:
            KeyError: If the key is missing from the data_paths configuration.
        """
        try:
            # 通过属性访问获取相对路径
            relative_path = getattr(self.config.data_paths, key, None)
            if relative_path is None:
                raise KeyError(f"配置错误: 'data_paths' 中缺少 '{key}'")

            abs_path = (self.scenario_dir / relative_path).resolve()
            if not abs_path.exists() and key != 'network':  # (路网暂时不管)
                print(f"警告: 数据文件未找到: {abs_path}")
            return abs_path
        except AttributeError:
            raise KeyError(f"配置错误: 'data_paths' 中缺少 '{key}'")

    def _load_mode_databases(self):
        """
        Load auxiliary mode database files (e.g. D2D or fixed route mode definitions).

        This populates self.mode_definitions with entries keyed by mode id so
        controllers can be initialized later.
        """
        print("Loading mode definitions...")

        # 1. 加载 D2D 模式 (如果文件存在)
        if self.config.data_paths.d2d_modes_db:
            d2d_db_path = self._get_data_path('d2d_modes_db')
            if d2d_db_path.exists():
                with open(d2d_db_path, 'r') as f:
                    d2d_modes = yaml.safe_load(f) or []  # (如果是空文件,返回空列表)
                    for mode_cfg in d2d_modes:
                        self.mode_definitions['d2d'][mode_cfg['id']] = mode_cfg
                print(
                    f"  - Loaded {len(self.mode_definitions['d2d'])} D2D mode definitions.")

        # 2. 加载 Fixed Route 模式 (如果文件存在)
        if self.config.data_paths.fixed_routes_db:
            fixed_db_path = self._get_data_path('fixed_routes_db')
            if fixed_db_path.exists():
                with open(fixed_db_path, 'r') as f:
                    fixed_modes = yaml.safe_load(f) or []
                    for mode_cfg in fixed_modes:
                        self.mode_definitions['fixed_route'][mode_cfg['id']] = mode_cfg
                print(
                    f"  - Loaded {len(self.mode_definitions['fixed_route'])} fixed_route definitions.")

    def build_environment(self) -> tuple[SimulationEngine, SimulationDataLogger]:
        # Convert Pydantic configuration objects into plain dictionaries to
        # maintain compatibility with the existing SimulationEngine and DemandGenerator APIs.
        sim_config = self.config.simulation.model_dump()

        self._load_mode_databases()

        strategies = {
            'NearestNeighbor': NearestNeighborStrategy(),
            'RL_Agent_1': RLStrategy(model_path="models/rl_agent_1.pth")
        }

        road_network_service = RoadNetworkService(
            str(self._get_data_path('network')))

        # The event broker decouples services and controllers via publish/subscribe
        event_broker = EventBroker()

        stop_service = StopService(event_broker=event_broker)
        stop_service.load_stops(self._get_data_path('stops'))

        demand_generator = DemandGenerator(
            zones_path=self._get_data_path('zones'),
            od_matrix_path=self._get_data_path('od_matrix'),
            sim_config=sim_config
        )

        demand_service = DemandStateService(
            demand_generator, event_broker)

        # 使用 FleetLoader 加载车队数据
        vehicles = FleetLoader.load_from_csv(
            fleet_file_path=self._get_data_path('fleet'))

        # 创建物理服务（负责车辆移动）
        physics_service = VehiclePhysicsService(vehicles=vehicles)

        # Stop operation service: handles boarding/alighting logic and stop queues
        stop_op_service = StopOperationService(
            stop_service=stop_service,
            demand_service=demand_service,
            event_broker=event_broker)

        vehicle_service = VehicleStateService(
            vehicles=vehicles,
            road_network_service=road_network_service,
            stop_operation_service=stop_op_service,
            event_broker=event_broker)

        # Separate services into physics (movement) and logic (state machines)
        physics_services = [physics_service]
        logic_services = [stop_service, demand_service, vehicle_service]

        # Initialize controllers based on loaded mode definitions
        controllers = []
        print("Initializing all defined controllers...")

        # --- 激活所有D2D模式 ---
        for mode_id, mode_cfg in self.mode_definitions['d2d'].items():
            # Resolve dispatch strategy implementation by name
            strategy = strategies.get(mode_cfg['dispatch_strategy'])
            if not strategy:
                raise ValueError(
                    f"D2D 模式 {mode_id} 的策略 {mode_cfg['dispatch_strategy']} 未定义。")

            print(f"  - Initializing D2D: {mode_id}")
            controllers.append(D2DController(
                mode_cfg,
                vehicle_query=vehicle_service,        # IVehicleQuery interface
                vehicle_dispatcher=vehicle_service,   # IVehicleDispatcher interface
                demand_service=demand_service,
                road_network=road_network_service,
                stop_service=stop_service,
                dispatch_strategy=strategy
            ))

        # --- 激活所有Fixed Route模式 ---
        for mode_id, mode_cfg in self.mode_definitions['fixed_route'].items():
            print(f"  - Initializing FixedRoute: {mode_id}")
            controllers.append(FixedRouteController(
                mode_cfg,
                vehicle_query=vehicle_service,
                vehicle_dispatcher=vehicle_service,
                demand_service=demand_service,
                road_network=road_network_service,
                stop_service=stop_service,
                event_broker=event_broker,
            ))

        data_logger = SimulationDataLogger()
        interfaces = [data_logger]

        engine = SimulationEngine(
            sim_config, physics_services, logic_services, controllers, interfaces)
        print("-------------------- Environment built, ready to run --------------------")
        return engine, data_logger


def main():
    parser = argparse.ArgumentParser(description="需求响应式公交 (DRT) 仿真")
    parser.add_argument(
        '--config',
        type=str,
        default="config/minimal/scenario.yaml",
        help="指向主场景配置文件的路径 (e.g., 'config/minimal/scenario.yaml')"
    )
    parser.add_argument(
        '--seed',
        type=int,
        default=42,
        help="Fixed random seed for reproducibility (affects random and numpy)."
    )

    args = parser.parse_args()

    # Initialize randomness for reproducible runs
    seed = args.seed
    print(f"Using fixed random seed: {seed}")

    # Set Python stdlib random
    random.seed(seed)

    # Set numpy RNG
    try:
        np.random.seed(seed)
    except Exception:
        # If numpy is unavailable or something goes wrong, continue without failing
        pass

    # Note: PYTHONHASHSEED affects hash() randomization at interpreter start; setting
    # it at runtime won't make hashing deterministic for the current process, but
    # we set it here for transparency / downstream subprocesses.
    os.environ.setdefault('PYTHONHASHSEED', str(seed))

    config_manager = ConfigurationManager(Path(args.config))
    sim_engine, data_logger = config_manager.build_environment()
    try:
        sim_engine.run()
    finally:
        data_logger.save()


if __name__ == "__main__":
    main()
