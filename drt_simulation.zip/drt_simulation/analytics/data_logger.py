import json
from typing import Any, Dict, List, Optional


class SimulationDataLogger:
    def __init__(self) -> None:
        self.snapshots: List[Dict[str, Any]] = []

    def update(self, current_time: float, time_step: float, services: List[Any]) -> None:
        vehicle_service = None
        demand_service = None
        for service in services:
            if service.__class__.__name__ == "VehicleStateService":
                vehicle_service = service
            elif service.__class__.__name__ == "DemandStateService":
                demand_service = service
        if vehicle_service is None or demand_service is None:
            return
        vehicles = [
            {
                "id": getattr(v, "veh_id", None),
                "lat": v.location[0] if hasattr(v, "location") else None,
                "lon": v.location[1] if hasattr(v, "location") else None,
                "load": getattr(v, "current_load", None),
                "capacity": getattr(v, "capacity", None),
                "status": getattr(v, "physical_status", None),
                "mode": getattr(v, "assigned_mode", None),
            }
            for v in getattr(vehicle_service, "vehicles", {}).values()
        ]
        requests = [
            {
                "id": getattr(r, "id", None),
                "origin": getattr(r, "origin", None),
                "destination": getattr(r, "destination", None),
                "status": str(getattr(r, "status", None)),
                "assigned_vehicle": getattr(r, "assigned_vehicle_id", None),
            }
            for r in getattr(demand_service, "requests", {}).values()
        ]
        self.snapshots.append({
            "time": current_time,
            "vehicles": vehicles,
            "requests": requests
        })

    def save(self, filename: str = "sim_result.json") -> None:
        with open(filename, "w", encoding="utf-8") as f:
            json.dump(self.snapshots, f, ensure_ascii=False, indent=2)
