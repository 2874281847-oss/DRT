# /services/road_network_service.py
from typing import List, Tuple


class RoadNetworkService:
    def __init__(self, map_path: str):
        print(f"Loading map from {map_path}...")
        # (加载路网图...)

    def get_shortest_path(self, start_loc: Tuple[float, float],
                          end_loc: Tuple[float, float]) -> Tuple[List[Tuple[float, float]], float]:
        """
        Compute a shortest physical path between two geographic coordinates.

        Returns a tuple (polyline_points, estimated_travel_time_seconds).
        """
        # (TODO: 寻路算法, e.g., A* or OSRM call)

        # 目前，先给定两个点的经纬度，在两点之间再插入一个点形成route
        path = [start_loc,
                ((start_loc[0] + end_loc[0]) / 2,
                 (start_loc[1] + end_loc[1]) / 2),
                end_loc]

        distance = 1000  # (假设 1000 米)
        return path, distance / 10.0  # (假设 10 m/s)

    def get_shortest_path_polyline(self, start: Tuple[float, float],
                                   end: Tuple[float, float]) -> List[Tuple[float, float]]:
        """
        Planning-layer interface: compute a detailed polyline between start and end.

        Controllers call this method during planning to obtain a sequence of
        waypoints for the vehicle to follow. The returned list should include
        both the start and end points and any intermediate waypoints.

        Note: current implementation returns a simple midpoint insertion for
        prototyping. Replace with a true routing algorithm (A*, Dijkstra, or
        an external router) for production use.
        """
        # 模拟路径规划：在两点之间插入一个中间点
        midpoint = (
            (start[0] + end[0]) / 2,
            (start[1] + end[1]) / 2
        )

        polyline = [start, midpoint, end]

        # TODO: 替换为实际的寻路算法
        # polyline = self._astar_search(start, end)

        return polyline
