# /services/demand_state_service.py
from typing import Dict, Optional, List, Any
from services.demand_generator import DemandGenerator
from entities.request import Request, RequestStatus, InvalidStateTransitionError
from core.event_broker import EventBroker
from core.events import EventTopic


class DemandStateService:
    """
    Manages demand state and the lifecycle of requests using an event-driven pattern.

    This service generates requests via a DemandGenerator, assigns them, and
    publishes events (e.g. REQUEST_CREATED, PASSENGER_BOARDED) for other
    services such as StopService to react to.
    """

    def __init__(self, generator: DemandGenerator, event_broker: EventBroker):
        self.requests: Dict[str, Request] = {}
        self.generator = generator  # 注入已实例化的 generator
        self.request_counter = 0
        self.event_broker = event_broker

        # Subscribe to vehicle events
        self.event_broker.subscribe(
            EventTopic.PASSENGER_BOARDED, self._on_passenger_boarded)
        self.event_broker.subscribe(
            EventTopic.PASSENGER_ALIGHTED, self._on_passenger_alighted)

    def update(self, current_time: int, time_step: int):
        """Process new requests and advance request state where applicable."""
        new_requests = self.generator.generate_requests(
            current_time, time_step)
        for req in new_requests:
            self.request_counter += 1
            req.id = f"req_{self.request_counter}"
            self.requests[req.id] = req
            print(f"[T={current_time}] 新订单: {req.id} (类型: {req.service_mode})")

            # 发布事件: 新订单已生成
            try:
                self.event_broker.publish(EventTopic.REQUEST_CREATED, req)
            except Exception as e:
                print(f"[DemandStateService] 发布 REQUEST_CREATED 事件失败: {e}")

        # Process requests that are waiting for stop
        for req in self.requests.values():
            if req.status == RequestStatus.WAITING_FOR_STOP:
                # (TODO: 实现步行到站点的模拟)
                # (简化: 假设乘客立即到站)
                self.passenger_arrives_at_stop(req.id)

    # --- New Semantic Methods (replacing command_update_status) ---

    def assign_to_vehicle(self, request_id: str, vehicle_id: Optional[str] = None,
                          pickup_stop_id: Optional[str] = None,
                          dropoff_stop_id: Optional[str] = None) -> bool:
        """
        Assign a request to a vehicle or to pickup/dropoff stops.

        Supports both STOP-based (fixed-route) assignments where pickup/dropoff
        stop IDs are provided, and DOOR-based (D2D) assignments where the
        request transitions to WAITING_FOR_PICKUP.

        Returns True if the assignment succeeded.
        """
        req = self.get_request_by_id(request_id)
        if not req:
            return False

        try:
            if vehicle_id:
                req.assigned_vehicle_id = vehicle_id

            if pickup_stop_id and dropoff_stop_id:
                # STOP-based assignment
                req.assigned_pickup_stop_id = pickup_stop_id
                req.assigned_dropoff_stop_id = dropoff_stop_id
                req.transition_to(RequestStatus.WAITING_FOR_STOP)
                print(f"[Demand] 订单 {req.id} 被指派到站点 {pickup_stop_id}, 开始前往站点。")
            else:
                # DOOR-based (D2D) assignment
                req.transition_to(RequestStatus.WAITING_FOR_PICKUP)
                print(f"[Demand] 订单 {req.id} (D2D) 已分配给车辆 {vehicle_id}, 在家等待。")

            return True
        except InvalidStateTransitionError as e:
            print(f"[Demand] 无法分配订单 {request_id}: {e}")
            return False

    def passenger_arrives_at_stop(self, request_id: str) -> bool:
        """
        Transition the request to WAITING_AT_STOP and publish an arrival event.

        This method signals StopService (via EventBroker) that a passenger has
        arrived and should be added to the stop queue.

        Returns True on success.
        """
        req = self.get_request_by_id(request_id)
        if not req:
            return False

        try:
            req.transition_to(RequestStatus.WAITING_AT_STOP)

            # Publish event so StopService can react
            self.event_broker.publish(EventTopic.PASSENGER_ARRIVED_AT_STOP, {
                'request_id': request_id,
                'stop_id': req.assigned_pickup_stop_id
            })
            return True
        except InvalidStateTransitionError as e:
            print(f"[Demand] 无法处理 {request_id} 到达站点: {e}")
            return False

    def cancel_request(self, request_id: str) -> bool:
        """
        Cancel the request and publish a REQUEST_CANCELLED event.

        Returns True if cancellation succeeded.
        """
        req = self.get_request_by_id(request_id)
        if not req:
            return False

        try:
            req.transition_to(RequestStatus.CANCELLED)
            self.event_broker.publish(EventTopic.REQUEST_CANCELLED, {
                'request_id': request_id
            })
            print(f"[Demand] 订单 {request_id} 已取消。")
            return True
        except InvalidStateTransitionError as e:
            print(f"[Demand] 无法取消 {request_id}: {e}")
            return False

    def get_request_by_id(self, request_id: str) -> Optional[Request]:
        return self.requests.get(request_id)

    def get_requests_by_filter(self, filter_function) -> List[Request]:
        return [req for req in self.requests.values() if filter_function(req)]

    # --- Event Callbacks ---
    def _on_passenger_boarded(self, data: dict):
        """
        Callback triggered when a passenger boards a vehicle.

        Transitions the request to IN_VEHICLE status using the state machine.
        """
        request_id = data.get('request_id')
        if request_id:
            req = self.get_request_by_id(request_id)
            if req:
                try:
                    req.transition_to(RequestStatus.IN_VEHICLE)
                except InvalidStateTransitionError as e:
                    print(f"[Demand] 无法将 {request_id} 标记为在车: {e}")

    def _on_passenger_alighted(self, data: dict):
        """
        Callback triggered when a passenger alights from a vehicle.

        Transitions the request to COMPLETED status using the state machine.
        """
        request_id = data.get('request_id')
        if request_id:
            req = self.get_request_by_id(request_id)
            if req:
                try:
                    req.transition_to(RequestStatus.COMPLETED)
                except InvalidStateTransitionError as e:
                    print(f"[Demand] 无法将 {request_id} 标记为完成: {e}")
