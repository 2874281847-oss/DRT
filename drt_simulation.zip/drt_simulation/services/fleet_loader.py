# /services/fleet_loader.py
import csv
from pathlib import Path
from typing import Dict

from entities.vehicle import Vehicle


class FleetLoader:
    """
    专门负责从 CSV 文件加载车队数据的加载器。

    提供一个静态方法来从 CSV 文件加载车辆列表，
    以将加载逻辑与 VehicleStateService 的运行时管理分离。

    公开 API:
        - load_from_csv(fleet_file_path: Path) -> Dict[str, Vehicle]: 
            从 CSV 路径加载车队并返回车辆字典。
    """

    @staticmethod
    def load_from_csv(fleet_file_path: Path) -> Dict[str, Vehicle]:
        """
        Load fleet data from a CSV file.

        Args:
            fleet_file_path: Path to the fleet CSV file.

        Returns:
            Dict mapping vehicle_id to Vehicle objects.

        Raises:
            FileNotFoundError: If the file does not exist.
            ValueError: If the CSV format is invalid.
        """
        if not fleet_file_path.exists():
            raise FileNotFoundError(f"车队文件未找到: {fleet_file_path}")

        vehicles: Dict[str, Vehicle] = {}

        print(f"Loading fleet from {fleet_file_path.name}...")

        with open(fleet_file_path, 'r', encoding='utf-8-sig') as f:
            # 跳过注释行以找到真正的头部
            header_line = ""
            while True:
                header_line = f.readline()
                if not header_line:
                    break
                header_line = header_line.strip()
                if header_line and not header_line.startswith('#'):
                    break

            if not header_line:
                print("  - 警告: 车队文件为空。")
                return vehicles

            headers = [h.strip() for h in header_line.split(',')]
            reader = csv.DictReader(f, fieldnames=headers)

            count = 0
            for row in reader:
                if not row[headers[0]] or row[headers[0]].startswith('#'):
                    continue

                new_vehicle = Vehicle(
                    veh_id=row['vehicle_id'],
                    capacity=int(row['capacity']),
                    start_location=(
                        float(row['start_lat']), float(row['start_lon'])),
                    assigned_mode=row['assigned_mode_id']
                )
                vehicles[new_vehicle.veh_id] = new_vehicle
                count += 1

            print(f"Loaded {count} vehicles.")

        return vehicles
