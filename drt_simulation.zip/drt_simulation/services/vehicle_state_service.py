# /services/vehicle_state_service.py
from typing import List, Tuple, Optional, Dict, Callable

from entities.vehicle import Vehicle
from entities.schedule import ScheduledPoint
from services.stop_operation_service import StopOperationService
from services.road_network_service import RoadNetworkService
from core.event_broker import EventBroker
from interfaces.vehicle_interfaces import IVehicleQuery, IVehicleDispatcher


class VehicleStateService(IVehicleQuery, IVehicleDispatcher):
    """
    Service responsible for vehicle state and position management.

    Implements two segregated interfaces:
        - IVehicleQuery: read-only accessors for vehicle state.
        - IVehicleDispatcher: command-based write operations (e.g. command_update_schedule).

    This enforces clear separation between controllers (which depend only on the
    interfaces) and the concrete service implementation.

    Public API:
        - update(current_time, time_step): Called by the simulation engine each step.
        - command_update_schedule(...): Overwrite a vehicle's schedule (used by RL/agents).
        - get_vehicle_by_id(...): Retrieve a vehicle by ID.
        - get_vehicles_by_filter(...): Retrieve vehicles matching a filter.

    Fleet data is loaded externally via FleetLoader and passed into this service.
    Internal helper methods (prefixed with '_') implement details such as path
    handling and arrival checks.
    """

    def __init__(self, vehicles: Dict[str, Vehicle],
                 road_network_service: RoadNetworkService,
                 stop_operation_service: StopOperationService,
                 event_broker: EventBroker):

        self.vehicles: Dict[str, Vehicle] = vehicles
        self.road_network_service = road_network_service
        self.stop_operation_service = stop_operation_service
        self.event_broker = event_broker

    def update(self, current_time: int, time_step: int):
        """Called by the simulation engine on each time step to advance vehicle state."""
        for veh in self.vehicles.values():
            # 检测是否到达并处理到达事件（业务逻辑）
            self._check_and_handle_arrival(veh, current_time)

    def _check_and_handle_arrival(self, veh: Vehicle, current_time: int):
        """Detect whether the vehicle has arrived and trigger business logic.

        If the vehicle has completed a scheduled leg, this will handle boarding/
        alighting and prepare the next leg or set the vehicle to IDLE.
        """
        if self._has_arrived_at_destination(veh):
            # 标记为停止（若尚未标记）
            veh.physical_status = 'STOPPED'
            # 处理到达事件（弹出调度点、上下客、准备下一段）
            self._handle_arrival_event(veh, current_time)

    def _has_arrived_at_destination(self, veh: Vehicle) -> bool:
        """Return True when vehicle has arrived at the current high-level scheduled point.

        Semantics: when the low-level route is exhausted and the vehicle is STOPPED
        while there remain ScheduledPoint items, we consider the vehicle to have
        arrived at the scheduled destination.
        """
        return veh.physical_status == 'STOPPED' and bool(veh.current_schedule)

    def _handle_arrival_event(self, veh: Vehicle, current_time: int):
        """Handle arrival business logic: pop scheduled point, do boarding/alighting,
        clear low-level route and start next leg or set vehicle to IDLE."""
        if not veh.current_schedule:
            return

        arrived_point = veh.current_schedule.pop(0)

        # 清理低级路径
        veh.current_route = []
        veh.current_route_segment_index = 0

        print(f"[T={current_time}] 车辆 {veh.veh_id} 到达 {arrived_point.point_id}")

        # 1. Boarding/alighting - delegate to StopOperationService
        self.stop_operation_service.process_stop_operations(
            veh, arrived_point, current_time)

        # 2. 准备下一段（如果有）
        if veh.current_schedule:
            self._start_next_leg_of_schedule(veh, current_time)
        else:
            veh.physical_status = 'IDLE'

    def _start_next_leg_of_schedule(self, veh: Vehicle, current_time: int):
        """
        Start the next leg of a vehicle's schedule using pre-computed paths.

        Execution layer reads ScheduledPoint.path_from_previous and replays the
        trajectory instead of performing routing here. This preserves the
        planning-vs-execution separation: controllers plan, this service executes.
        """
        if not veh.current_schedule:
            veh.physical_status = 'IDLE'
            return

        next_point = veh.current_schedule[0]
        print('next point is:', next_point)

        # [关键改变] 从预计算的路径中读取，而不是现场寻路
        # 如果 ScheduledPoint 有 path_from_previous，直接使用它
        # 否则回退到简单的两点直线路径
        if next_point.path_from_previous:
            path_nodes = next_point.path_from_previous
        else:
            # 回退逻辑：直接连接当前位置和目标位置
            path_nodes = [veh.location, next_point.location]

        # Safety: a path must contain at least two points (start and end) to move
        if len(path_nodes) < 2:
            print(
                f"警告: 车辆 {veh.veh_id} 无法执行前往 {next_point.point_id} 的路径, 路径点不足。")
            return

        # 2. [关键] 设置车辆的"低级任务"
        veh.current_route = path_nodes

        # 3. 我们从第 0 段开始 (即 route[0] -> route[1])
        veh.current_route_segment_index = 0

        veh.physical_status = 'MOVING'
        print(f"[T={current_time}] 车辆 {veh.veh_id} 开始新任务: 前往 {next_point.point_id} "
              f"(路径共 {len(path_nodes)} 个点)")

    # --- 核心指令 API (RL的接口) ---
    def command_update_schedule(self, vehicle_id: str,
                                new_schedule: List[ScheduledPoint],
                                current_time: int):
        """ [RL Agent的核心接口] 强制更新车辆的完整任务列表 """
        veh = self.get_vehicle_by_id(vehicle_id)
        if not veh:
            return

        veh.current_schedule = new_schedule
        print(f"[T={current_time}] 车辆 {vehicle_id} 调度被RL Agent更新. "
              f"新列表首项: {new_schedule[0].point_id if new_schedule else '空'}")

        # 如果车辆不在执行任务, 或新任务的第一站和旧的不同, 立即重新规划
        if veh.physical_status != 'MOVING' and veh.current_schedule:
            self._start_next_leg_of_schedule(veh, current_time)
        # (更复杂的逻辑: 检查第一站是否变化, 如果变化, 也要调用 _start...)

    def get_vehicle_by_id(self, vehicle_id: str) -> Optional[Vehicle]:
        return self.vehicles.get(vehicle_id)

    def get_vehicles_by_filter(self, filter_function: Callable[[Vehicle], bool]) -> List[Vehicle]:
        return [veh for veh in self.vehicles.values() if filter_function(veh)]
