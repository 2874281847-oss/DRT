"""
Stop operation service for DRT simulation.

This service handles stop-related operations including passenger boarding and
alighting. It supports both fixed-route stops and door-to-door (D2D) points.
"""

from typing import Optional

from entities.vehicle import Vehicle
from entities.schedule import ScheduledPoint, StopPoint
from services.demand_state_service import DemandStateService
from services.stop_service import StopService
from core.event_broker import EventBroker
from core.events import EventTopic


class StopOperationService:
    """
    Manages all boarding and alighting operations at scheduled points.

    Responsibilities:
        - Execute boarding and alighting at stops/door points
        - Publish passenger events to the EventBroker
        - Query stop passenger queues via StopService
    """

    def __init__(self,
                 stop_service: StopService,
                 demand_service: DemandStateService,
                 event_broker: EventBroker):
        """
        Initialize StopOperationService with required dependencies.

        Args:
            stop_service: Service managing stop locations and queues
            demand_service: Service managing request lifecycle
            event_broker: Event broker for publishing events
        """
        self.stop_service = stop_service
        self.demand_service = demand_service
        self.event_broker = event_broker

    def process_stop_operations(self,
                                vehicle: Vehicle,
                                arrived_point: ScheduledPoint,
                                current_time: int) -> None:
        """
        Execute boarding and alighting logic for an arrived scheduled point.

        This routine handles both fixed-route stops and D2D door points and
        publishes PASSENGER_ALIGHTED and PASSENGER_BOARDED events as needed.

        Args:
            vehicle: Vehicle that has arrived at the scheduled point.
            arrived_point: ScheduledPoint describing pickups/dropoffs at location.
            current_time: Current simulation time (seconds).
        """

        # --- 1. Handle all alighting tasks ---
        passengers_to_drop = [
            p for p in vehicle.requests_on_board
            if p.id in arrived_point.dropoff_request_ids
        ]

        # --- Prepare boarding list (collect first, then print for accuracy) ---
        req_ids_to_board = set(arrived_point.pickup_request_ids)

        passengers_waiting_at_stop = set()
        if isinstance(arrived_point, StopPoint) and vehicle.assigned_mode == 'FIXED_ROUTE':
            stop_id = arrived_point.stop_id
            passengers_waiting_at_stop = self.stop_service.get_passengers_at_stop(
                stop_id)
            if passengers_waiting_at_stop:
                print(
                    f"  [FixedRoute] 站点 {stop_id} 有 {len(passengers_waiting_at_stop)} 名乘客正在等待.")
            req_ids_to_board.update(passengers_waiting_at_stop)

        # Filter for requests that are truly eligible for pickup
        # (exclude completed or non-waiting requests)
        eligible_pickup_ids = []
        for rid in req_ids_to_board:
            r = self.demand_service.get_request_by_id(rid)
            if r and r.status_allows_pickup():
                eligible_pickup_ids.append(rid)

        print(f"  - 处理上下客任务: "
              f"准备让 {len(passengers_to_drop)} 名乘客下车, 准备让 {len(eligible_pickup_ids)} 名乘客上车.")

    # --- 2. Execute alighting ---
        for passenger_req in passengers_to_drop:
            # Tell the vehicle to alight the passenger (encapsulates state mutation)
            vehicle.alight_passenger(passenger_req)
            # Publish event: passenger alighted
            self.event_broker.publish(EventTopic.PASSENGER_ALIGHTED, {
                'request_id': passenger_req.id,
                'vehicle_id': vehicle.veh_id,
                'time': current_time,
                'location': vehicle.location
            })
            print(f"  - 乘客 (Req: {passenger_req.id}) 下车. "
                  f"当前负载: {vehicle.current_load}/{vehicle.capacity}")

    # --- 3. Execute boarding ---
        # Iterate through eligible_pickup_ids, whether from D2D or FixedRoute
        for req_id in eligible_pickup_ids:
            # Get request object from DemandService
            passenger_req = self.demand_service.get_request_by_id(req_id)

            # Check if passenger is truly waiting
            if not passenger_req or not passenger_req.status_allows_pickup():
                # Passenger not in waiting state (may be cancelled or picked up by another vehicle)
                continue

            # Use Vehicle's command interface for boarding; keep if-check to stop boarding when full
            if vehicle.board_passenger(passenger_req):
                # Publish event: passenger boarded
                self.event_broker.publish(EventTopic.PASSENGER_BOARDED, {
                    'request_id': req_id,
                    'vehicle_id': vehicle.veh_id,
                    'time': current_time
                })
                print(f"  + 乘客 (Req: {req_id}) 上车. "
                      f"当前负载: {vehicle.current_load}/{vehicle.capacity}")
            else:
                # Vehicle is at capacity, stop boarding
                print(f"  ! 车辆 {vehicle.veh_id} 满载, 无法接起 {req_id}. 停止上客.")
                break
