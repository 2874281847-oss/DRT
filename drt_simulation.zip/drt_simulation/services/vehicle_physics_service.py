# /services/vehicle_physics_service.py
from typing import Dict

from entities.vehicle import Vehicle
from utils.utils import calculate_distance, move_towards


class VehiclePhysicsService:
    """
    Manages the pure physics of vehicle movement.

    This service is responsible for:
    - Calculating distance traveled based on vehicle speed and time step
    - Updating vehicle positions along their routes
    - Does NOT handle business logic like boarding/alighting passengers or scheduling

    Public API:
        - update(current_time: int, time_step: int): Called by simulation engine each step
    """

    SIM_VEHICLE_SPEED_MPS = 50  # meters per second

    def __init__(self, vehicles: Dict[str, Vehicle]):
        """
        Initialize the physics service.

        Args:
            vehicles: Dictionary mapping vehicle IDs to Vehicle objects
        """
        self.vehicles: Dict[str, Vehicle] = vehicles

    def update(self, current_time: int, time_step: int):
        """
        Update the physical position of all moving vehicles.

        Called by the simulation engine on each time step.
        Iterates through all vehicles and if they are MOVING, calculates
        the distance they travel and updates their position along the route.

        Args:
            current_time: Current simulation time (in seconds)
            time_step: Duration of this time step (in seconds)
        """
        for veh in self.vehicles.values():
            if veh.physical_status == 'MOVING':
                self._tick_movement(veh, time_step)

    def _tick_movement(self, veh: Vehicle, time_step: int):
        """
        Perform pure physics movement: calculate distance and update vehicle position.

        This method:
        - Calculates the distance to travel based on speed and time step
        - Updates vehicle position along the route using the guarded update_physics_state() method
        - Does NOT handle arrivals, boarding, or scheduling

        The Vehicle object is a data container for physical properties (location, route, segment index, status).
        This method respects the Vehicle's encapsulation by using update_physics_state() instead of
        directly mutating attributes.

        Args:
            veh: The vehicle to move
            time_step: Duration of this time step (in seconds)
        """

        # Progress display: compute percent along the current low-level segment
        # and print for debugging (keeps existing per-vehicle debug behavior).
        if veh.current_route and len(veh.current_route) >= 2:
            ori_idx = veh.current_route_segment_index
            tgt_idx = min(ori_idx + 1, len(veh.current_route) - 1)
            origin = veh.current_route[ori_idx]
            target = veh.current_route[tgt_idx]
            seg_len = calculate_distance(origin, target)
            dist_to_target_start = calculate_distance(veh.location, target)
            progress_start = 0.0
            if seg_len > 0:
                progress_start = max(
                    0.0, min(1.0, 1 - dist_to_target_start / seg_len))

            # Only print verbose per-vehicle to avoid flooding logs; keep v_fixed_1 as example
            # if veh.veh_id == 'v_fixed_1':
            #     print(f"[progress] {veh.veh_id} seg {ori_idx}->{tgt_idx} "
            #           f"{progress_start*100:.1f}% loc={veh.location} target={target}")

        if not veh.current_route:
            return  # No route to travel

        # Calculate distance this vehicle can travel in this time step
        distance_to_travel = self.SIM_VEHICLE_SPEED_MPS * time_step

    # --- Movement logic (pure physics only) ---
    # Boundary check: no route to follow
        if veh.current_route_segment_index >= len(veh.current_route) - 1:
            # [关键改变] 使用 update_physics_state() 而不是直接赋值
            veh.update_physics_state(
                veh.current_route[-1], veh.current_route_segment_index, 'STOPPED')
            return

        remaining_distance = distance_to_travel

    # Iterate movement until remaining distance is exhausted or route end reached
        while remaining_distance > 0 and veh.current_route_segment_index < len(veh.current_route) - 1:
            origin_point_index = veh.current_route_segment_index
            target_point_index = origin_point_index + 1

            origin_point = veh.current_route[origin_point_index]
            target_point = veh.current_route[target_point_index]

            # Compute distance to next target point
            # segment total length and current distance-to-target
            segment_length = calculate_distance(origin_point, target_point)
            dist_to_target = calculate_distance(veh.location, target_point)

            if remaining_distance >= dist_to_target:
                # Enough distance to reach the next point: move directly to it
                # Use update_physics_state() to atomically update location/index/status
                veh.update_physics_state(
                    target_point, origin_point_index + 1, 'MOVING')
                remaining_distance -= dist_to_target

                # Log that we reached the next point and index incremented
                # if veh.veh_id == 'v_fixed_1':
                #     print(
                #         f"[progress] {veh.veh_id} reached target idx={target_point_index} (segment complete)")

            else:
                # Not enough distance to reach the next point: move part-way
                new_location = move_towards(
                    veh.location, target_point, remaining_distance)
                # [关键改变] 使用 update_physics_state() 原子性地更新位置，同时保持段索引不变
                veh.update_physics_state(
                    new_location, veh.current_route_segment_index, 'MOVING')
                remaining_distance = 0
                # Compute progress after partial move and print
                try:
                    if segment_length > 0 and veh.veh_id == 'v_fixed_1':
                        new_dist = calculate_distance(
                            new_location, target_point)
                        progress = max(
                            0.0, min(1.0, 1 - (new_dist / segment_length)))
                        # print(f"[progress] {veh.veh_id} seg {origin_point_index}->{target_point_index} "
                        #       f"{progress*100:.1f}%")
                except Exception:
                    pass

        # 检查是否已到达路径末尾
        if veh.current_route_segment_index >= len(veh.current_route) - 1:
            # [关键改变] 使用 update_physics_state() 而不是直接赋值
            veh.update_physics_state(
                veh.current_route[-1], veh.current_route_segment_index, 'STOPPED')
