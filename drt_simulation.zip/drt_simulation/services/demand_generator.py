# /services/demand_generator.py
import yaml
import csv
import random
import math
import folium
from typing import Dict, List, Tuple
from pathlib import Path

from entities.request import Request


class DemandGenerator:
    """
    Loads zone and OD matrix configuration and generates stochastic demand.

    Requests are produced following a Poisson process derived from OD counts.
    This class provides utilities for reading CSV configuration and turning
    OD counts into per-second arrival rates used by the simulator.
    """

    def __init__(self, zones_path: Path, od_matrix_path: Path, sim_config: dict):

        self.timeslice_duration: int = sim_config.get(
            'timeslice_duration_seconds', 3600)
        self.sim_start_time_offset: int = sim_config.get(
            'start_time_of_day_seconds', 0)

        self.zones: Dict[str, Dict] = self._load_zones(zones_path)

        # _load_od_matrix 现在也需要读取 service_mode
        self.od_matrix: Dict[int, List[dict]
                             ] = self._load_od_matrix(od_matrix_path)

        self.od_probabilities: Dict[int, List[dict]
                                    ] = self._convert_od_to_probabilities()

        print(
            f"[DemandGenerator] 成功加载 {len(self.zones)} 个区域和 {len(self.od_matrix)} 个时间片的OD数据.")

    def _load_zones(self, zones_file: Path) -> Dict[str, Dict]:
        zones = {}
        with open(zones_file, 'r', encoding='utf-8-sig') as f:
            # (使用健壮的CSV读取器)
            header_line = ""
            while True:  # (跳过注释)
                header_line = f.readline()
                if not header_line:
                    return {}
                header_line = header_line.strip()
                if header_line and not header_line.startswith('#'):
                    break

            headers = [h.strip() for h in header_line.split(',')]
            reader = csv.DictReader(f, fieldnames=headers)

            for row in reader:
                if not row[headers[0]] or row[headers[0]].startswith('#'):
                    continue
                zones[row['zone_id']] = {
                    'center': (float(row['center_lat']), float(row['center_lon'])),
                    'radius': float(row['radius_meters'])
                }
        return zones

    def _load_od_matrix(self, matrix_file: Path) -> Dict[int, List[dict]]:
        # 直接存储原始行
        # Store the raw rows keyed by time slice index
        matrix: Dict[int, List[dict]] = {}
        with open(matrix_file, 'r', encoding='utf-8-sig') as f:
            header_line = ""
            while True:  # (跳过注释)
                header_line = f.readline()
                if not header_line:
                    return {}
                header_line = header_line.strip()
                if header_line and not header_line.startswith('#'):
                    break

            headers = [h.strip() for h in header_line.split(',')]
            reader = csv.DictReader(f, fieldnames=headers)

            for row in reader:
                if not row[headers[0]] or row[headers[0]].startswith('#'):
                    continue

                ts_index = int(row['time_slice_index'])
                if ts_index not in matrix:
                    matrix[ts_index] = []

                # 存储整行数据
                matrix[ts_index].append(row)
        return matrix

    def _convert_od_to_probabilities(self) -> Dict[int, List[dict]]:
        # Convert OD counts into per-second Poisson rates and attach to rows
        probabilities_map = {}
        for ts_index, rows in self.od_matrix.items():
            probabilities_map[ts_index] = []
            for row in rows:
                total_requests = int(row['total_requests'])
                lambda_per_second = 0.0
                if total_requests > 0:
                    lambda_per_second = total_requests / self.timeslice_duration

                prob_row = row.copy()
                prob_row['lambda_per_second'] = lambda_per_second
                probabilities_map[ts_index].append(prob_row)
        return probabilities_map

    def generate_requests(self, current_time: int, time_step: int) -> List[Request]:
        new_requests = []
        # [修改] 使用我们测试通过的逻辑
        current_timeslice_index = current_time // self.timeslice_duration

        if current_timeslice_index not in self.od_probabilities:
            return []

        active_od_rows = self.od_probabilities[current_timeslice_index]

        for row in active_od_rows:
            lambda_per_second = row['lambda_per_second']
            if lambda_per_second <= 0:
                continue

            prob_at_least_one = 1 - math.exp(-lambda_per_second * time_step)

            if random.random() < prob_at_least_one:
                o_id = row['origin_zone_id']
                d_id = row['destination_zone_id']
                service_mode = row['service_mode'].upper()

                o_zone = self.zones[o_id]
                d_zone = self.zones[d_id]

                o_loc = self._randomize_location_in_circle(
                    o_zone['center'], o_zone['radius'])
                d_loc = self._randomize_location_in_circle(
                    d_zone['center'], d_zone['radius'])

                new_req = Request(
                    request_id="temp",
                    origin=o_loc,
                    destination=d_loc,
                    request_time=current_time,
                    num_passengers=1
                )

                # Set the service mode for the generated request (DOOR or STOP)
                new_req.service_mode = service_mode
                new_requests.append(new_req)

        return new_requests

    def _randomize_location_in_circle(self, center_loc: Tuple[float, float], radius_meters: float) -> Tuple[float, float]:
        """Generate a randomized coordinate inside an approximate circle.

        Args:
            center_loc: Center coordinate (lat, lon).
            radius_meters: Radius in meters for the circle.

        Returns:
            A randomized coordinate (lat, lon) within the circle.
        """
        center_lat, center_lon = center_loc
        center_lat_rad = math.radians(center_lat)

        r = radius_meters * math.sqrt(random.random())
        theta = random.random() * 2 * math.pi

        dx = r * math.cos(theta)
        dy = r * math.sin(theta)

        lat_offset_deg = dy / 111111.0
        lon_offset_deg = dx / (111111.0 * math.cos(center_lat_rad))

        return (center_lat + lat_offset_deg, center_lon + lon_offset_deg)

    # --- 绘图功能 ---
    def _get_hexagon_vertices(self, center_loc: Tuple[float, float], radius_meters: float) -> List[Tuple[float, float]]:
        """Compute the six vertices of a (flat-top) hexagon centered at center_loc.

        Args:
            center_loc: Center coordinate (lat, lon).
            radius_meters: Radius in meters.

        Returns:
            List of six (lat, lon) vertex coordinates.
        """
        center_lat, center_lon = center_loc
        center_lat_rad = math.radians(center_lat)
        vertices = []

        # 假设 0 度为平顶 (即 3 点钟方向)
        for i in range(6):
            # 角度: 0, 60, 120, 180, 240, 300
            angle_deg = 60 * i
            angle_rad = math.radians(angle_deg)

            # 转换为米
            dx = radius_meters * math.cos(angle_rad)
            dy = radius_meters * math.sin(angle_rad)

            # 转换为经纬度偏移
            lat_offset_deg = dy / 111111.0
            lon_offset_deg = dx / (111111.0 * math.cos(center_lat_rad))

            # folium 要求 (lat, lon) 顺序
            vertices.append((center_lat + lat_offset_deg,
                            center_lon + lon_offset_deg))

        return vertices

    def plot_zones(self, output_file: str = "zones_map.html"):
        """Render loaded hexagonal zones onto a Folium map and save to a file.

        Args:
            output_file: Path where the HTML map will be written.
        """
        if not self.zones:
            print("没有可绘制的区域。")
            return

        # 使用第一个区域作为地图中心
        first_zone_loc = list(self.zones.values())[0]['center']
        m = folium.Map(location=first_zone_loc, zoom_start=13)

        for zone_id, zone_data in self.zones.items():
            center_loc = zone_data['center']
            radius = zone_data['radius']

            # 1. 计算六边形顶点
            vertices = self._get_hexagon_vertices(center_loc, radius)

            # 2. 绘制六边形
            folium.Polygon(
                locations=vertices,
                color="blue",
                fill=True,
                fill_color="blue",
                fill_opacity=0.2,
                tooltip=f"Zone ID: {zone_id}"
            ).add_to(m)

            # 3. 标记中心点
            folium.Marker(
                location=center_loc,
                popup=f"ID: {zone_id}\nRadius: {radius}m"
            ).add_to(m)

        m.save(output_file)
        print(f"Map saved to: {output_file}")
