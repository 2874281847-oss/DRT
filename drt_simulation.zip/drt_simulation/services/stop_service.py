# /services/stop_service.py
import csv
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Set
from entities.stop import Stop
from core.event_broker import EventBroker


class StopService:
    """
    Manages stops and passenger queues using an event-driven architecture.

    StopService subscribes to demand events (PASSENGER_ARRIVED_AT_STOP,
    PASSENGER_BOARDED) and maintains the waiting passenger sets for each stop.
    """

    def __init__(self, event_broker: Optional[EventBroker] = None):
        self.stops: Dict[str, Stop] = {}
        self.event_broker = event_broker
        print("StopService initialized (empty).")

        # Subscribe to demand events if event_broker is provided
        if self.event_broker:
            self.event_broker.subscribe(
                "PASSENGER_ARRIVED_AT_STOP", self._on_passenger_arrived)
            self.event_broker.subscribe(
                "PASSENGER_BOARDED", self._on_passenger_boarded)

    # [修改] 接收一个文件路径
    def load_stops(self, stops_file_path: Path):
        """Load stops from a CSV file into the service's stop dictionary.

        Args:
            stops_file_path: Path to the stops CSV.
        """
        print(f"Loading stops from {stops_file_path.name}...")

        with open(stops_file_path, 'r', encoding='utf-8-sig') as f:
            header_line = ""
            while True:  # (跳过注释)
                header_line = f.readline()
                if not header_line:
                    break
                header_line = header_line.strip()
                if header_line and not header_line.startswith('#'):
                    break

            if not header_line:  # file is empty
                print("  - Warning: stops file is empty.")
                return

            headers = [h.strip() for h in header_line.split(',')]
            reader = csv.DictReader(f, fieldnames=headers)

            count = 0
            for row in reader:
                if not row[headers[0]] or row[headers[0]].startswith('#'):
                    continue

                new_stop = Stop(
                    stop_id=row['stop_id'],
                    location=(float(row['center_lat']),
                              float(row['center_lon'])),
                    name=row.get('stop_name', "")
                )
                self.stops[new_stop.id] = new_stop
                count += 1

            print(f"Loaded {count} stops.")

    # ... (get_stop, get_passengers_at_stop 等函数保持不变) ...
    def get_stop(self, stop_id: str) -> Optional[Stop]:
        return self.stops.get(stop_id)

    def get_passengers_at_stop(self, stop_id: str) -> Set[str]:
        stop = self.get_stop(stop_id)
        if stop:
            return set(stop.waiting_passengers)
        return set()

    def get_nearest_stop(self, location: Tuple[float, float]) -> Optional[Stop]:
        """Find the stop nearest to the given location (lat, lon).

        Uses a simplified squared-euclidean distance on lat/lon for speed.
        Returns None if no stops are loaded.
        """
        if not self.stops:
            return None

        def _calc_dist_sq(loc1, loc2):  # simplified squared distance on lat/lon
            return (loc1[0] - loc2[0])**2 + (loc1[1] - loc2[1])**2

        min_dist_sq = float('inf')
        nearest_stop = None

        for stop in self.stops.values():
            dist_sq = _calc_dist_sq(location, stop.location)
            if dist_sq < min_dist_sq:
                min_dist_sq = dist_sq
                nearest_stop = stop

        return nearest_stop

    def add_passenger_to_stop_queue(self, request_id: str, stop_id: str):
        stop = self.get_stop(stop_id)
        if stop:
            stop.waiting_passengers.add(request_id)
            print(f"[StopService] 乘客 {request_id} 现于站点 {stop_id} 等待.")
        else:
            print(f"警告: 尝试将乘客添加到不存在的站点 {stop_id}.")

    def remove_passenger_from_stop_queue(self, request_id: str, stop_id: str):
        stop = self.get_stop(stop_id)
        if stop:
            stop.waiting_passengers.discard(request_id)

    # --- Event Callbacks (Event-Driven Architecture) ---

    def _on_passenger_arrived(self, data: dict):
        """
        Event handler for when a passenger arrives at a stop.

        Automatically adds the passenger to the stop's waiting queue.

        Args:
            data: Event data containing 'request_id' and 'stop_id'
        """
        request_id = data.get('request_id')
        stop_id = data.get('stop_id')
        if request_id and stop_id:
            self.add_passenger_to_stop_queue(request_id, stop_id)

    def _on_passenger_boarded(self, data: dict):
        """
        Event handler for when a passenger boards a vehicle.

        Automatically removes the passenger from the stop's waiting queue.

        Args:
            data: Event data containing 'request_id' and optionally 'stop_id'
        """
        request_id = data.get('request_id')
        # We need to find which stop(s) this passenger was waiting at
        # For now, we'll search through all stops
        for stop in self.stops.values():
            if request_id in stop.waiting_passengers:
                self.remove_passenger_from_stop_queue(request_id, stop.id)
                break
