class Controller:
    """Simple playground example demonstrating bound methods."""

    def __init__(self):
        self.data = 100

    def on_event(self, msg):
        print(self.data)


c = Controller()
handler = c.on_event  # handler is a bound method
print(handler)

# Verify that the handler holds a reference to the instance c
print(handler.__self__ is c)  # prints: True
