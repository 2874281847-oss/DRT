# /entities/stop.py
from typing import Tuple, Set


class Stop:
    """
    Data entity representing a physical transit stop.

    Attributes:
        id: Stop identifier.
        location: Tuple(latitude, longitude) of the stop.
        name: Optional human-readable name.
        waiting_passengers: Set of request IDs currently waiting at this stop.
    """

    def __init__(self, stop_id: str, location: Tuple[float, float], name: str = ""):
        self.id = stop_id
        self.location = location  # (lat, lon)
        self.name = name

        # Runtime state: request IDs of passengers waiting at this stop
        self.waiting_passengers: Set[str] = set()
