# /entities/request.py
from enum import Enum
from typing import Any, Tuple, Literal, Optional


class RequestStatus(Enum):
    """Enumeration of all valid request statuses."""
    WAITING_ASSIGNMENT = 'WAITING_ASSIGNMENT'
    WAITING_FOR_STOP = 'WAITING_FOR_STOP'
    WAITING_AT_STOP = 'WAITING_AT_STOP'
    WAITING_FOR_PICKUP = 'WAITING_FOR_PICKUP'
    IN_VEHICLE = 'IN_VEHICLE'
    COMPLETED = 'COMPLETED'
    CANCELLED = 'CANCELLED'


class InvalidStateTransitionError(Exception):
    """Exception raised when an invalid state transition is attempted."""
    pass


class Request:
    """
    Represents a transportation request with a centralized state machine.

    The status follows strict transitions defined in _VALID_TRANSITIONS. Use
    transition_to() to perform safe state changes.
    """

    # Define valid state transitions
    _VALID_TRANSITIONS = {
        RequestStatus.WAITING_ASSIGNMENT: [
            RequestStatus.WAITING_FOR_STOP,
            RequestStatus.WAITING_FOR_PICKUP,
            RequestStatus.CANCELLED
        ],
        RequestStatus.WAITING_FOR_STOP: [
            RequestStatus.WAITING_AT_STOP,
            RequestStatus.CANCELLED
        ],
        RequestStatus.WAITING_AT_STOP: [
            RequestStatus.IN_VEHICLE,
            RequestStatus.CANCELLED
        ],
        RequestStatus.WAITING_FOR_PICKUP: [
            RequestStatus.IN_VEHICLE,
            RequestStatus.CANCELLED
        ],
        RequestStatus.IN_VEHICLE: [
            RequestStatus.COMPLETED,
            RequestStatus.CANCELLED
        ],
        RequestStatus.COMPLETED: [],
        RequestStatus.CANCELLED: []
    }

    def __init__(self, request_id: str, origin: Tuple[float, float],
                 destination: Tuple[float, float], request_time: int,
                 num_passengers: int = 1):
        self.id = request_id
        self.origin = origin
        self.destination = destination
        self.request_time = request_time

        # 区分"单子"和"乘客": 本单包含几人
        self.num_passengers: int = num_passengers

        # 门到门接送，还是站点接送
        self.service_mode: Literal['DOOR', 'STOP', 'UNKNOWN'] = 'UNKNOWN'

        # 使用 RequestStatus 枚举管理状态（初始为 WAITING_ASSIGNMENT）
        self.status: RequestStatus = RequestStatus.WAITING_ASSIGNMENT

        self.assigned_vehicle_id: Optional[str] = None

        # 服务模式中包含站点的情况
        self.assigned_pickup_stop_id: Optional[str] = None
        self.assigned_dropoff_stop_id: Optional[str] = None

    def transition_to(self, new_status: RequestStatus) -> None:
        """
        Transition the request to a new status.

        Only transitions allowed by _VALID_TRANSITIONS are permitted. An
        InvalidStateTransitionError is raised for invalid transitions.

        Args:
            new_status: The target RequestStatus to transition to.

        Raises:
            InvalidStateTransitionError: If the transition is not valid.
        """
        if new_status not in self._VALID_TRANSITIONS.get(self.status, []):
            raise InvalidStateTransitionError(
                f"Cannot transition from {self.status.value} to {new_status.value}"
            )
        self.status = new_status

    def status_allows_pickup(self) -> bool:
        """Helper: return True if the request is in a pickup-eligible state."""
        return self.status in [RequestStatus.WAITING_AT_STOP, RequestStatus.WAITING_FOR_PICKUP]

    def __repr__(self) -> str:
        return (f"Request(id={self.id}, origin={self.origin}, "
                f"destination={self.destination}, request_time={self.request_time}, "
                f"num_passengers={self.num_passengers}, service_mode={self.service_mode}, "
                f"status={self.status.value})")
