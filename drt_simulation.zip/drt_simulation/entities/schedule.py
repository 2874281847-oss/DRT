# /entities/schedule.py

from typing import List, Tuple, Optional
from abc import ABC, abstractmethod


class ScheduledPoint(ABC):
    """
    Abstract base class for a high-level scheduled point created by Controllers.

    A ScheduledPoint represents a physical location a vehicle should visit and
    the tasks to perform there (pickups/dropoffs). The important attribute
    `path_from_previous` contains a polyline computed by the planning layer and
    played back by the execution layer (VehicleStateService) to separate
    planning from execution.

    Subclasses:
        StopPoint: Used for fixed-route stops.
        DoorPoint: Used for door-to-door (D2D) points.
    """

    def __init__(self,
                 location: Tuple[float, float],
                 pickup_request_ids: List[str],
                 dropoff_request_ids: List[str],
                 point_id: str,
                 path_from_previous: Optional[List[Tuple[float, float]]] = None):

        # 物理位置 (用于路网寻路)
        self.location: Tuple[float, float] = location

        # 任务列表: 要在此点接上的乘客 (的订单ID)
        self.pickup_request_ids: List[str] = pickup_request_ids

        # 任务列表: 要在此点放下的乘客 (的订单ID)
        self.dropoff_request_ids: List[str] = dropoff_request_ids

        # 逻辑ID (e.g., 'Stop_A' or 'Req_B_Pickup')
        self.point_id: str = point_id

        # [关键] 详细轨迹: 从前一个点到此点的折线坐标列表
        # 由 Controller 的规划层事先计算，包含从前一点出发和到此点结束的路径
        self.path_from_previous: List[Tuple[float, float]
                                      ] = path_from_previous if path_from_previous is not None else []

    @property
    @abstractmethod
    def point_type(self) -> str:
        """
        Return the point type string.

        Subclasses must return either 'STOP' or 'DOOR'. This helps maintain
        compatibility with existing logging and code paths.
        """
        pass

    def __repr__(self) -> str:
        return (f"{self.__class__.__name__}(id={self.point_id}, type={self.point_type}, "
                f"location={self.location}, pickups={self.pickup_request_ids}, "
                f"dropoffs={self.dropoff_request_ids})")


class StopPoint(ScheduledPoint):
    """
    Scheduled point representing a fixed-route stop. `point_id` is the stop ID.
    """

    def __init__(self,
                 location: Tuple[float, float],
                 pickup_request_ids: List[str],
                 dropoff_request_ids: List[str],
                 stop_id: str,
                 path_from_previous: Optional[List[Tuple[float, float]]] = None):
        """
        Initialize a StopPoint.

        Args:
            location: Geographic location of the stop (lat, lon).
            pickup_request_ids: List of request IDs to be picked up here.
            dropoff_request_ids: List of request IDs to be dropped off here.
            stop_id: Logical stop identifier (e.g., 'Stop_A').
            path_from_previous: Polyline from the previous point.
        """
        super().__init__(
            location=location,
            pickup_request_ids=pickup_request_ids,
            dropoff_request_ids=dropoff_request_ids,
            point_id=stop_id,
            path_from_previous=path_from_previous
        )
        self.stop_id: str = stop_id

    @property
    def point_type(self) -> str:
        return 'STOP'


class DoorPoint(ScheduledPoint):
    """
    Scheduled point representing a door-to-door location. `point_id` can be a
    request-related identifier for D2D operations.
    """

    def __init__(self,
                 location: Tuple[float, float],
                 pickup_request_ids: List[str],
                 dropoff_request_ids: List[str],
                 point_id: str,
                 path_from_previous: Optional[List[Tuple[float, float]]] = None):
        """
        Initialize a DoorPoint.

        Args:
            location: Geographic coordinate of the door point (lat, lon).
            pickup_request_ids: List of request IDs to pick up at this point.
            dropoff_request_ids: List of request IDs to drop off at this point.
            point_id: Logical identifier for the point (e.g., 'Req_B_Pickup').
            path_from_previous: Polyline from the previous point.
        """
        super().__init__(
            location=location,
            pickup_request_ids=pickup_request_ids,
            dropoff_request_ids=dropoff_request_ids,
            point_id=point_id,
            path_from_previous=path_from_previous
        )

    @property
    def point_type(self) -> str:
        return 'DOOR'
