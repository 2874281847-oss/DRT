# /entities/vehicle.py
from typing import List, Tuple, Literal, Optional
from entities.schedule import ScheduledPoint
from entities.request import Request


class Vehicle:
    def __init__(self, veh_id: str, capacity: int, start_location: Tuple[float, float], assigned_mode: str):
        """
        Lightweight vehicle data container.

        Attributes:
            veh_id: Unique identifier for the vehicle.
            capacity: Maximum passenger capacity.
            start_location: Initial (latitude, longitude) of the vehicle.
            assigned_mode: Mode id this vehicle serves (e.g. 'D2D', 'FIXED_ROUTE').
        """
        self.veh_id: str = veh_id
        self.capacity: int = capacity
        self.location: Tuple[float, float] = start_location

        # List of Request objects currently on board
        self.requests_on_board: List[Request] = []
        # Current onboard passenger count
        self.current_load: int = 0
        # Service mode assigned to this vehicle
        self.assigned_mode: str = assigned_mode  # 'D2D' | 'FIXED_ROUTE'

        # Runtime-managed physical state (maintained by services/controllers)
        self.physical_status: Literal['IDLE', 'MOVING', 'STOPPED'] = 'IDLE'

        # High-level schedule (list of ScheduledPoint) that controllers modify
        self.current_schedule: List[ScheduledPoint] = []
        # Low-level route (polyline) for the current leg; used by physics service
        self.current_route: List[Tuple[float, float]] = []
        # Index of the current segment within current_route (0 means route[0]->route[1])
        self.current_route_segment_index: int = 0

    # --- 辅助属性 ---
    @property
    def waiting_passengers_count(self) -> int:
        """Compute the number of assigned-but-not-yet-boarded passengers.

        Returns:
            Sum of pickup_request_ids across scheduled points.
        """
        count = 0
        for sp in self.current_schedule:
            count += len(sp.pickup_request_ids)
        return count

    @property
    def total_committed_load(self) -> int:
        """Total committed load: onboard passengers plus scheduled pickups."""
        return self.current_load + self.waiting_passengers_count

    # --- 载客操作封装 (Tell, Don't Ask) ---
    def can_board(self, num_passengers: int) -> bool:
        """Return True if the vehicle can board num_passengers without exceeding capacity."""
        return (self.current_load + num_passengers) <= self.capacity

    def board_passenger(self, request: Request) -> bool:
        """
        Attempt to board the passenger(s) described by the Request.

        If capacity allows, append the Request to self.requests_on_board and update
        self.current_load, returning True. Otherwise return False and make no
        modification.
        """
        if not request:
            return False

        if self.can_board(request.num_passengers):
            self.requests_on_board.append(request)
            self.current_load += request.num_passengers
            return True
        return False

    def alight_passenger(self, request: Request):
        """
        Remove the given Request from the vehicle if present and update load.

        This method only updates the vehicle's internal data and does not
        publish any external state changes.
        """
        if not request:
            return

        try:
            self.requests_on_board.remove(request)
            self.current_load -= request.num_passengers
            if self.current_load < 0:
                # 保持防护，避免负载变为负数
                self.current_load = 0
        except ValueError:
            # 请求不在车上，忽略
            pass

    # --- [关键] 物理状态管理 (Guarded Data Container Pattern) ---
    def update_physics_state(self, new_location: Tuple[float, float],
                             route_index: int, status: Literal['IDLE', 'MOVING', 'STOPPED']) -> None:
        """
        Atomically update the vehicle's physical state.

        This method implements a guarded update pattern so that location,
        route index, and physical status remain consistent. VehicleStateService
        should prefer this method over direct attribute assignment.

        Args:
            new_location: New geographic coordinate (lat, lon).
            route_index: Index of the current route segment (0 means route[0]->route[1]).
            status: One of 'IDLE', 'MOVING', or 'STOPPED'.
        """

        # Debug hook: log updates for a specific vehicle when investigating
        # if getattr(self, 'veh_id', None) == 'v_fixed_1':
        #     try:
        #         print(
        #             f"[update_physics_state] {self.veh_id}: loc={new_location}, route_index={route_index}, status={status}")
        #     except Exception:
        #         # Avoid any debug logging from raising during simulation
        #         pass

        self.location = new_location
        self.current_route_segment_index = route_index
        self.physical_status = status

    # --- 调度管理封装 (Tell, Don't Ask) ---
    def assign_pickup_to_stop(self, stop_id: str, request_id: str) -> bool:
        """
        Try to add the request_id to the pickup list for the given stop in the schedule.

        Returns True if the request_id was added, False otherwise (already present or no matching point).
        """
        for scheduled_point in self.current_schedule:
            if scheduled_point.point_id == stop_id:
                if request_id not in scheduled_point.pickup_request_ids:
                    scheduled_point.pickup_request_ids.append(request_id)
                    return True
                # request_id 已存在，返回 False（避免重复）
                return False
        # 未找到对应的 ScheduledPoint
        return False

    def assign_dropoff_to_stop(self, stop_id: str, request_id: str) -> bool:
        """
        Try to add the request_id to the dropoff list for the given stop in the schedule.

        Returns True if the request_id was added, False otherwise.
        """
        for scheduled_point in self.current_schedule:
            if scheduled_point.point_id == stop_id:
                if request_id not in scheduled_point.dropoff_request_ids:
                    scheduled_point.dropoff_request_ids.append(request_id)
                    return True
                # request_id 已存在，返回 False（避免重复）
                return False
        # 未找到对应的 ScheduledPoint
        return False
