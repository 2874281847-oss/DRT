"""
Vehicle service interfaces using Protocol-based duck typing.

This module defines read-only (Query) and write-only (Command) interfaces
to enforce strict boundary separation between controllers and the vehicle state service.

Rationale:
    - IVehicleQuery: Exposes only read operations (safe for multiple consumers)
    - IVehicleDispatcher: Exposes only command operations (write operations)
    - Prevents controllers from calling internal methods like update() directly
    - Implements Interface Segregation Principle (ISP)
"""

from typing import Protocol, List, Callable, Optional
from entities.vehicle import Vehicle
from entities.schedule import ScheduledPoint


class IVehicleQuery(Protocol):
    """
    Read-only interface for querying vehicle state.

    Controllers implementing this interface can only READ vehicle state,
    not modify it directly. This enforces a command/query separation.
    """

    def get_vehicle_by_id(self, vehicle_id: str) -> Optional[Vehicle]:
        """
        Retrieve a vehicle by its ID.

        Args:
            vehicle_id: The unique identifier of the vehicle.

        Returns:
            The Vehicle object if found, None otherwise.
        """
        ...

    def get_vehicles_by_filter(
        self, filter_function: Callable[[Vehicle], bool]
    ) -> List[Vehicle]:
        """
        Retrieve vehicles matching the provided filter function.

        Args:
            filter_function: A callable that takes a Vehicle and returns True
                           if it matches the filter criteria.

        Returns:
            A list of Vehicle objects matching the filter.
        """
        ...


class IVehicleDispatcher(Protocol):
    """
    Write-only interface for dispatching commands to vehicles.

    Controllers implementing this interface can only SEND COMMANDS to vehicles,
    not read state directly. This ensures:
    - Commands are the only way to modify vehicle state
    - Strong encapsulation of internal state management
    - Explicit intent through command semantics
    """

    def command_update_schedule(
        self, vehicle_id: str, new_schedule: List[ScheduledPoint], current_time: int
    ) -> None:
        """
        Send a command to update a vehicle's schedule.

        This is the primary interface for external systems (e.g., RL agents,
        scheduling algorithms) to modify vehicle routes and tasks.

        Args:
            vehicle_id: The unique identifier of the vehicle to command.
            new_schedule: A list of ScheduledPoint objects representing
                        the new complete schedule.
            current_time: The current simulation time for logging/context.

        Returns:
            None. State mutations are side effects of this command.

        Raises:
            Implicitly may log warnings if vehicle_id not found.
        """
        ...
