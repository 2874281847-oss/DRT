"""
Interfaces package for DRT simulation.

This package defines protocol-based interfaces following the Interface Segregation Principle.
Protocols provide duck-typing support without requiring explicit inheritance.
"""

from interfaces.vehicle_interfaces import IVehicleQuery, IVehicleDispatcher

__all__ = ["IVehicleQuery", "IVehicleDispatcher"]
