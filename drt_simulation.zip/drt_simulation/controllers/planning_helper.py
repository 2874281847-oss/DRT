# /controllers/planning_helper.py
"""
Controller Planning Helper Module

This module provides the "Chain Planning" logic for the Planning Layer.
Controllers use these helpers to generate ScheduledPoint objects with pre-calculated
path_from_previous polylines, implementing the Planning-Execution separation pattern.
"""

from typing import List, Tuple, Literal
from entities.vehicle import Vehicle
from entities.schedule import ScheduledPoint, StopPoint, DoorPoint
from services.road_network_service import RoadNetworkService


class ControllerPlanningHelper:
    """
    Helper for Controllers to generate path-aware schedules using "Chain Planning".

    Chain Planning Logic:
    1. Start with current_cursor = vehicle.location (or last point in existing schedule)
    2. For each new task to assign:
       - Call road_network_service.get_shortest_path_polyline(current_cursor, task_location)
       - Create ScheduledPoint with this path_from_previous
       - Update current_cursor = task_location

    This ensures every ScheduledPoint carries its detailed trajectory, allowing
    VehicleStateService to simply "play back" pre-calculated paths.
    """

    def __init__(self, road_network_service: RoadNetworkService):
        """
        Initialize the planning helper.

        Args:
            road_network_service: Service for calculating path polylines
        """
        self.road_network = road_network_service

    def create_scheduled_point_with_path(
        self,
        location: Tuple[float, float],
        point_type: Literal['STOP', 'DOOR'],
        pickup_request_ids: List[str],
        dropoff_request_ids: List[str],
        point_id: str,
        path_from_previous: List[Tuple[float, float]]
    ) -> ScheduledPoint:
        """
        Factory method to create a ScheduledPoint with path information.
        根据 point_type 参数实例化具体的 StopPoint 或 DoorPoint。

        Args:
            location: The location of this scheduled point
            point_type: 'STOP' or 'DOOR'
            pickup_request_ids: List of request IDs to pick up at this point
            dropoff_request_ids: List of request IDs to drop off at this point
            point_id: Logical ID for this point
            path_from_previous: The pre-calculated polyline from the previous point

        Returns:
            A new StopPoint or DoorPoint instance with the path embedded
        """
        if point_type == 'STOP':
            return StopPoint(
                location=location,
                pickup_request_ids=pickup_request_ids,
                dropoff_request_ids=dropoff_request_ids,
                stop_id=point_id,
                path_from_previous=path_from_previous
            )
        elif point_type == 'DOOR':
            return DoorPoint(
                location=location,
                pickup_request_ids=pickup_request_ids,
                dropoff_request_ids=dropoff_request_ids,
                point_id=point_id,
                path_from_previous=path_from_previous
            )
        else:
            raise ValueError(f"Unknown point_type: {point_type}")

    def chain_plan_route(
        self,
        vehicle: Vehicle,
        task_locations: List[Tuple[str, Tuple[float, float],
                                   Literal['STOP', 'DOOR'], List[str], List[str]]]
    ) -> List[ScheduledPoint]:
        """
        Execute "Chain Planning" to generate a complete schedule with polylines.

        This is the core method for planning. It calculates paths between consecutive
        points and embeds them in the ScheduledPoint objects.

        Args:
            vehicle: The vehicle to assign tasks to
            task_locations: List of tuples (point_id, location, point_type, pickups, dropoffs)
                           representing tasks in the order they should be visited

        Returns:
            A new schedule list where each ScheduledPoint has path_from_previous calculated

        Example:
            >>> tasks = [
            ...     ('Stop_A', (39.9, 116.4), 'STOP', ['req_1'], []),
            ...     ('Stop_B', (39.91, 116.41), 'STOP', [], ['req_1']),
            ... ]
            >>> schedule = helper.chain_plan_route(vehicle, tasks)
            >>> # Each point in schedule now has a pre-calculated polyline
        """
        new_schedule: List[ScheduledPoint] = []

        # Start from vehicle's current location
        current_cursor = vehicle.location

        # If vehicle is already on a schedule with remaining points, consider that
        if vehicle.current_schedule and len(vehicle.current_schedule) > 0:
            # Start from the first point in the existing schedule
            current_cursor = vehicle.current_schedule[0].location

        # Chain planning: iterate through tasks and calculate paths
        for point_id, location, point_type, pickup_ids, dropoff_ids in task_locations:
            # [Planning Layer] Calculate the path from current position to this task location
            path_polyline = self.road_network.get_shortest_path_polyline(
                current_cursor, location
            )

            # Create ScheduledPoint with the pre-calculated path
            scheduled_point = self.create_scheduled_point_with_path(
                location=location,
                point_type=point_type,
                pickup_request_ids=pickup_ids,
                dropoff_request_ids=dropoff_ids,
                point_id=point_id,
                path_from_previous=path_polyline
            )

            new_schedule.append(scheduled_point)

            # Update cursor for next iteration
            current_cursor = location

            print(f"  [Planning] Generated path from {current_cursor} to {point_id} "
                  f"with {len(path_polyline)} waypoints")

        return new_schedule

    def append_tasks_to_schedule(
        self,
        vehicle: Vehicle,
        new_tasks: List[Tuple[str, Tuple[float, float],
                              Literal['STOP', 'DOOR'], List[str], List[str]]]
    ) -> List[ScheduledPoint]:
        """
        Append new tasks to an existing schedule while maintaining path consistency.

        This method handles the case where a vehicle already has an active schedule
        and new tasks are being inserted. It preserves the existing schedule and
        extends it with properly planned new tasks.

        Args:
            vehicle: The vehicle whose schedule is being extended
            new_tasks: List of tasks to append

        Returns:
            The complete updated schedule (existing + newly planned tasks)
        """
        # Keep existing schedule items
        updated_schedule = list(vehicle.current_schedule)

        # Determine starting point for planning new tasks
        if updated_schedule:
            # Start from the last point in the current schedule
            current_cursor = updated_schedule[-1].location
        else:
            # Start from vehicle's current location
            current_cursor = vehicle.location

        # Plan and append new tasks
        for point_id, location, point_type, pickup_ids, dropoff_ids in new_tasks:
            # [Planning Layer] Calculate path from last point to new task
            path_polyline = self.road_network.get_shortest_path_polyline(
                current_cursor, location
            )

            scheduled_point = self.create_scheduled_point_with_path(
                location=location,
                point_type=point_type,
                pickup_request_ids=pickup_ids,
                dropoff_request_ids=dropoff_ids,
                point_id=point_id,
                path_from_previous=path_polyline
            )

            updated_schedule.append(scheduled_point)
            current_cursor = location

            print(f"  [Planning] Appended task {point_id} to schedule "
                  f"with {len(path_polyline)} waypoints")

        return updated_schedule


# ============================================================================
# Example Usage Pattern (for Controller developers):
# ============================================================================

def example_controller_usage():
    """
    Demonstrates how a Controller should use the planning helper
    to implement "Chain Planning" when assigning tasks to vehicles.

    This is an example pattern for implementing _assign_tasks_to_vehicle()
    in Controllers like D2DController or FixedRouteController.
    """
    # Pseudo-code showing the pattern:

    # In a Controller's dispatch method:
    # 1. Initialize the planning helper
    # planning_helper = ControllerPlanningHelper(self.road_network)

    # 2. Prepare tasks (point_id, location, type, pickups, dropoffs)
    # tasks = [
    #     ('Stop_1', (39.90, 116.40), 'STOP', ['req_001'], []),
    #     ('Stop_2', (39.91, 116.41), 'STOP', [], ['req_001']),
    # ]

    # 3. Generate schedule with pre-calculated paths
    # new_schedule = planning_helper.chain_plan_route(vehicle, tasks)

    # 4. Assign to vehicle via VehicleStateService
    # self.vehicle_service.command_update_schedule(
    #     vehicle.veh_id, new_schedule, current_time
    # )

    # Now VehicleStateService will:
    # - Read pre-calculated paths from each ScheduledPoint
    # - Play back these paths without additional computation
    # - Achieve "Physics-layer" pure execution

    pass
