from services.vehicle_state_service import VehicleStateService
from services.demand_state_service import DemandStateService
from services.stop_service import StopService
from services.road_network_service import RoadNetworkService


class IServiceModeController:
    """
    Base interface for service-mode controllers.

    Controllers that manage a particular transport mode (D2D, fixed-route, etc.)
    should inherit from this class. Controllers are expected to implement an
    update(current_time, time_step) method that the simulation engine calls on
    every step.
    """

    def __init__(self, config, vehicle_service, demand_service, road_network, stop_service):
        self.config = config
        self.vehicle_service: VehicleStateService = vehicle_service
        self.demand_service: DemandStateService = demand_service
        self.road_network: RoadNetworkService = road_network
        self.stop_service: StopService = stop_service
        self.my_vehicles = set()  # (由配置注入)

    def update(self, current_time, time_step):
        """Called by the simulation engine each time step.

        Subclasses must implement this method to perform mode-specific
        decision-making and command issuance.
        """
        raise NotImplementedError
