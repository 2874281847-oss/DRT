# /controllers/d2d_controller.py
from controllers.base_controller import IServiceModeController
from strategies.base_strategy import IDispatchStrategy
from entities.request import RequestStatus
from interfaces.vehicle_interfaces import IVehicleQuery, IVehicleDispatcher
# (导入 Services...)


class D2DController(IServiceModeController):
    """
    Door-to-door (D2D) demand-responsive transport controller.

    The controller follows an interface-segregation pattern: it receives
    read-only vehicle state access via IVehicleQuery and issues commands via
    IVehicleDispatcher. This separation helps enforce correct usage and keeps
    the controller from mutating internal service state directly.
    """

    def __init__(self, config, vehicle_query: IVehicleQuery, vehicle_dispatcher: IVehicleDispatcher,
                 demand_service, road_network, stop_service, dispatch_strategy: IDispatchStrategy):
        """
        Initialize the D2D controller with segregated vehicle interfaces.

        Args:
            config: Mode configuration dictionary.
            vehicle_query: IVehicleQuery interface for reading vehicle state.
            vehicle_dispatcher: IVehicleDispatcher interface for commanding vehicles.
            demand_service: Demand state service.
            road_network: Road network service.
            stop_service: Stop service.
            dispatch_strategy: Dispatch strategy (RL agent or algorithm).

        Note:
            For backward compatibility the base initializer is called with a
            placeholder vehicle_service; controllers should prefer the provided
            IVehicleQuery/IVehicleDispatcher interfaces.
        """
        # Initialize parent with minimal vehicle_service (needed for base class compatibility)
        super().__init__(config, None, demand_service, road_network, stop_service)

        # Inject segregated interfaces (the primary dependency)
        self.vehicle_query: IVehicleQuery = vehicle_query
        self.vehicle_dispatcher: IVehicleDispatcher = vehicle_dispatcher

        # Strategy encapsulates dispatch decision-making logic
        self.strategy = dispatch_strategy
        # How often (in seconds) this controller should run its decision loop
        self.decision_interval = config.get('decision_interval', 10)

    def update(self, current_time: int, time_step: int):
        """
        Main decision-making loop for D2D dispatch.

        The loop follows three phases:
        1. Query phase: use IVehicleQuery for read-only state collection.
        2. Plan phase: the strategy computes decisions (assignments/updates).
        3. Command phase: IVehicleDispatcher is used to apply the decisions.
        """

        # 1. Check whether it's time to make a dispatch decision
        if current_time % self.decision_interval != 0:
            return

        # 2. Collect state required for decision-making (idle vehicles, pending requests)
        # Use IVehicleQuery for read-only access to vehicle state
        # Get all requests waiting for assignment
        pending_requests = self.demand_service.get_requests_by_filter(
            lambda r: getattr(
                r, 'status', None) == RequestStatus.WAITING_ASSIGNMENT
        )
        # Query phase: get vehicles via the IVehicleQuery interface
        my_vehicles = self.vehicle_query.get_vehicles_by_filter(
            lambda v: v.assigned_mode == self.config['id']
        )

        if not pending_requests and not any(v.physical_status != 'IDLE' for v in my_vehicles):
            return  # No pending requests and no active vehicles -> no decision needed

    # 3. Call the dispatch strategy to produce a list of commands/decisions.
    # The strategy should return a list of tuples like
    # ('update_schedule', 'veh_1', new_schedule_list)
        decisions = self.strategy.make_decisions(
            current_time,
            my_vehicles,
            pending_requests,
            self.road_network  # strategy may need road network for estimates
        )

    # 4. Execute the decisions using the IVehicleDispatcher command interface.
    # Only the dispatcher should be used to mutate vehicle state.
        for decision in decisions:
            cmd, veh_id, new_schedule = decision
            if cmd == 'update_schedule':
                # Command: Update vehicle schedule via dispatcher (write-only)
                self.vehicle_dispatcher.command_update_schedule(
                    veh_id, new_schedule, current_time)
                # Also mark the involved requests as assigned in DemandStateService
                # by transitioning them to WAITING_FOR_PICKUP to avoid re-assignment
                # in the next decision epoch.
                try:
                    for point in new_schedule or []:
                        pickup_ids = getattr(
                            point, 'pickup_request_ids', []) or []
                        for req_id in pickup_ids:
                            # assign_to_vehicle will perform state transition
                            self.demand_service.assign_to_vehicle(
                                req_id, vehicle_id=veh_id)
                except Exception as e:
                    print(
                        f"[D2DController] Failed to assign requests to {veh_id}: {e}")
