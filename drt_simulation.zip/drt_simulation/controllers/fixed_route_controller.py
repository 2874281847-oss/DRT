# /controllers/fixed_route_controller.py
from typing import Dict, List, Optional, Tuple, Literal, cast
from controllers.base_controller import IServiceModeController
from controllers.planning_helper import ControllerPlanningHelper
# (确保导入 Services, ScheduledPoint, Vehicle, Request ...)
from entities.schedule import ScheduledPoint, StopPoint
from entities.request import Request, RequestStatus
from core.event_broker import EventBroker
from interfaces.vehicle_interfaces import IVehicleQuery, IVehicleDispatcher


class FixedRouteController(IServiceModeController):
    """
    Controller that manages vehicle-passenger matching for fixed-route services.

    This controller handles requests that are of type 'STOP' when both origin
    and destination nearest stops are part of the controller's configured
    stop sequence.
    """

    def __init__(
        self,
        config,
        vehicle_query: IVehicleQuery,
        vehicle_dispatcher: IVehicleDispatcher,
        demand_service,
        road_network,
        stop_service,
        event_broker: EventBroker,
    ):
        # Keep compatibility with base signature by passing None for vehicle_service
        super().__init__(config, None, demand_service, road_network, stop_service)

        # Save query/dispatcher interfaces
        self.vehicle_query = vehicle_query
        self.vehicle_dispatcher = vehicle_dispatcher

        # Load the sequence of stops served by this route
        self.stop_sequence: List[str] = config['stops_sequence']

        # Use IVehicleQuery to get vehicles that belong to this controller
        self.my_vehicle_ids: List[str] = [
            v.veh_id
            for v in self.vehicle_query.get_vehicles_by_filter(
                lambda v: v.assigned_mode == self.config['id']
            )
        ]

        # Initialize schedules for vehicles assigned to this controller
        self._initialize_vehicle_schedules(current_time=0)

        # Event subscription: listen for new request creation events
        self.event_broker = event_broker
        self.event_broker.subscribe(
            "REQUEST_CREATED", self._on_request_created)

    def _initialize_vehicle_schedules(self, current_time: int):
        """
        Create a full ScheduledPoint list for all owned vehicles at simulation start.

        For each vehicle assigned to this fixed route, build a circular schedule of
        StopPoint entries corresponding to the controller's stop_sequence and
        push the schedule to the vehicle via the dispatcher.

        Uses ControllerPlanningHelper to generate path-aware schedules with
        pre-calculated polylines for each segment, following the Planning-Execution
        separation pattern.
        """
        if not self.my_vehicle_ids:
            return

        # Instantiate the planning helper with the road network service
        helper = ControllerPlanningHelper(self.road_network)

        for veh_id in self.my_vehicle_ids:
            # Retrieve the vehicle object
            vehicle = self.vehicle_query.get_vehicle_by_id(veh_id)
            if not vehicle:
                continue

            # Construct the task list for chain planning
            tasks: List[Tuple[str, Tuple[float, float],
                              Literal['STOP'], List[str], List[str]]] = []

            for stop_id in self.stop_sequence:
                stop_entity = self.stop_service.get_stop(stop_id)
                if stop_entity:
                    # Each task is: (point_id, location, point_type, pickup_ids, dropoff_ids)
                    tasks.append((
                        stop_id,
                        stop_entity.location,
                        'STOP',
                        [],  # empty pickup_ids for initialization
                        []   # empty dropoff_ids for initialization
                    ))

            # Make the route circular by appending the first stop to the end
            if len(tasks) > 1:
                first_task = tasks[0]
                tasks.append(first_task)

            # Generate the schedule with path-aware ScheduledPoint objects
            new_schedule = helper.chain_plan_route(
                vehicle,
                cast(List[Tuple[str, Tuple[float, float],
                     Literal['STOP', 'DOOR'], List[str], List[str]]], tasks)
            )

            self.vehicle_dispatcher.command_update_schedule(
                veh_id, new_schedule, current_time
            )

    def update(self, current_time: int, time_step: int):
        """
        No-op update; fixed-route request handling is event-driven.

        FixedRouteController relies on the `_on_request_created` callback to
        handle new STOP requests, so it does not poll for requests each time
        step.
        """
        return

    def _on_request_created(self, req: Request) -> None:
        """
        Callback invoked when a new request is created.

        Only processes STOP-type requests that are in WAITING_ASSIGNMENT state.
        """
        if not req:
            return

        # Only handle STOP requests that have not yet been assigned
        if req.status != RequestStatus.WAITING_ASSIGNMENT or req.service_mode != 'STOP':
            return

        # 1) 找到最近 O/D 站点
        pickup_stop = self.stop_service.get_nearest_stop(req.origin)
        dropoff_stop = self.stop_service.get_nearest_stop(req.destination)

        if not pickup_stop or not dropoff_stop:
            return

        pickup_stop_id = pickup_stop.id
        dropoff_stop_id = dropoff_stop.id

        # 2) Check whether both origin and destination stops are served by this route
        if ((pickup_stop_id != dropoff_stop_id) and
            (pickup_stop_id in self.stop_sequence) and
                (dropoff_stop_id in self.stop_sequence)):

            print(f"[{self.config['id']}] 接管订单 {req.id} (STOP类型)。")
            print(f"  - 乘客 O ({req.origin}) -> 最近站点 {pickup_stop_id}")
            print(f"  - 乘客 D ({req.destination}) -> 最近站點 {dropoff_stop_id}")

            # Instruct the demand service to assign the request to a vehicle/stop
            self.demand_service.assign_to_vehicle(
                req.id,
                vehicle_id=None,  # FixedRoute does not require a specific vehicle id
                pickup_stop_id=pickup_stop_id,
                dropoff_stop_id=dropoff_stop_id
            )

            # Simple heuristic: choose the vehicle with the smallest committed load
            candidate_vehicles = [
                self.vehicle_query.get_vehicle_by_id(vid) for vid in self.my_vehicle_ids
            ]
            candidate_vehicles = [v for v in candidate_vehicles if v]
            if candidate_vehicles:
                chosen = min(candidate_vehicles,
                             key=lambda v: v.total_committed_load)

                # Use Vehicle methods to assign pickups/dropoffs (tell, don't ask)
                pickup_assigned = chosen.assign_pickup_to_stop(
                    pickup_stop_id, req.id)
                dropoff_assigned = chosen.assign_dropoff_to_stop(
                    dropoff_stop_id, req.id)

                if pickup_assigned:
                    r = self.demand_service.get_request_by_id(req.id)
                    if r:
                        r.assigned_vehicle_id = chosen.veh_id
                    print(
                        f"  [ASSIGN] Assigned request {req.id} to vehicle {chosen.veh_id}, pickup {pickup_stop_id}.")

                if dropoff_assigned:
                    print(
                        f"  [ASSIGN] Set request {req.id} to drop off at {dropoff_stop_id}.")
