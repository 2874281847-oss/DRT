# /strategies/rl_strategy.py
from typing import List, Dict, Any
from strategies.base_strategy import IDispatchStrategy
from entities.vehicle import Vehicle
from entities.request import Request
from entities.schedule import ScheduledPoint


class RLStrategy(IDispatchStrategy):
    """
    Reinforcement Learning based dispatch strategy stub.

    The concrete implementation should load an RL model and translate
    environment observations into actions that map to simulator commands
    (e.g., 'update_schedule').
    """

    def __init__(self, model_path: str):
        # TODO: load RL agent model from model_path
        # self.rl_agent = load_model(model_path)
        pass

    def _build_observation(self, vehicles: List[Vehicle], requests: List[Request]):
        """
        Convert simulator state into an RL observation tensor/structure.

        Implementations should assemble vehicle and request features required
        by the RL agent.
        """
        pass

    def _parse_action(self, action, vehicles, requests, road_network):
        """
        Convert RL agent actions into simulator command tuples.

        The parser must map agent outputs into a list of decisions such as
        ('update_schedule', vehicle_id, new_schedule).
        """

        # Pseudocode:
        # new_schedule_for_veh_A = [ ... ]
        # decisions = [ ('update_schedule', 'Veh_A_id', new_schedule_for_veh_A) ]
        # return decisions
        pass

    def make_decisions(self, current_time, vehicles, requests, road_network) -> List:
        # 1. Build observation
        observation = self._build_observation(vehicles, requests)
        # 2. Query the RL agent for an action
        # action = self.rl_agent.get_action(observation)
        # 3. Parse the action into simulator decisions
        # decisions = self._parse_action(action, vehicles, requests, road_network)
        # return decisions
        return []  # currently a no-op
