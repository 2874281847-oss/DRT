class IDispatchStrategy:
    """
    Dispatch strategy interface (base class).

    Implementations should provide a make_decisions method that consumes the
    current simulation state and returns a list of dispatch commands.
    """

    def make_decisions(self, current_time, vehicles: list, requests: list, road_network=None) -> list:
        """
        Args:
            current_time: Current simulation time in seconds.
            vehicles: List of available vehicle objects.
            requests: List of pending Request objects.
            road_network: Optional RoadNetworkService for travel time estimates.

        Returns:
            A list of decision tuples, e.g. (command_name, vehicle_id, payload).
        """
        raise NotImplementedError
