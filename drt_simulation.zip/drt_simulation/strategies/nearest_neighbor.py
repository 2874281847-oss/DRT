from strategies.base_strategy import IDispatchStrategy
from entities.schedule import DoorPoint
from utils.utils import calculate_distance


class NearestNeighborStrategy(IDispatchStrategy):
    """
    A simple greedy nearest-neighbor dispatch strategy for D2D mode.

    For each request in WAITING_ASSIGNMENT, find the closest IDLE vehicle
    (by euclidean-like distance) and assign a two-point DoorPoint schedule
    (pickup then dropoff). Once a vehicle is assigned it is removed from the
    candidate pool for the current decision epoch.
    """

    def make_decisions(self, current_time, vehicles: list, requests: list, road_network=None):
        decisions = []

        # 1) Filter waiting requests and idle vehicles
        def _is_waiting(r):
            st = getattr(r, 'status', None)
            if st is None:
                return False
            # compare by name if enum-like, else by value
            try:
                return st.name == 'WAITING_ASSIGNMENT' or st == st.__class__.WAITING_ASSIGNMENT
            except Exception:
                return str(st) == 'RequestStatus.WAITING_ASSIGNMENT' or str(st) == 'WAITING_ASSIGNMENT'

        waiting_requests = [r for r in requests if _is_waiting(r)]

        idle_vehicles = [v for v in vehicles if getattr(
            v, 'physical_status', None) == 'IDLE']

        # If either list empty, return no decisions
        if not waiting_requests or not idle_vehicles:
            return []

        # copy list so we can remove assigned vehicles
        available_vehicles = list(idle_vehicles)

        for req in waiting_requests:
            if not available_vehicles:
                break

            # compute distances from req.origin to each available vehicle
            origin = getattr(req, 'origin', None)
            if origin is None:
                continue

            best_vehicle = None
            best_dist = None
            for veh in available_vehicles:
                veh_loc = getattr(veh, 'location', None)
                if veh_loc is None:
                    continue

                try:
                    dist = calculate_distance(origin, veh_loc)
                except Exception:
                    # fallback to simple Euclidean calculation if utils unavailable
                    try:
                        dx = origin[0] - veh_loc[0]
                        dy = origin[1] - veh_loc[1]
                        dist = (dx*dx + dy*dy) ** 0.5
                    except Exception:
                        dist = float('inf')

                if best_dist is None or dist < best_dist:
                    best_dist = dist
                    best_vehicle = veh

            if best_vehicle is None:
                continue

            # Build DoorPoint pickup and dropoff
            pickup_path = []
            dropoff_path = []
            try:
                if road_network:
                    pickup_path = road_network.get_shortest_path_polyline(
                        best_vehicle.location, req.origin)
                    dropoff_path = road_network.get_shortest_path_polyline(
                        req.origin, req.destination)
            except Exception:
                # If road network call fails, keep empty paths
                pickup_path = pickup_path or []
                dropoff_path = dropoff_path or []

            pickup_point = DoorPoint(
                location=req.origin,
                pickup_request_ids=[req.id],
                dropoff_request_ids=[],
                point_id=f"{req.id}_pickup",
                path_from_previous=pickup_path
            )

            dropoff_point = DoorPoint(
                location=req.destination,
                pickup_request_ids=[],
                dropoff_request_ids=[req.id],
                point_id=f"{req.id}_dropoff",
                path_from_previous=dropoff_path
            )

            # create decision and remove vehicle from available pool
            decisions.append(('update_schedule', best_vehicle.veh_id, [
                             pickup_point, dropoff_point]))
            available_vehicles.remove(best_vehicle)

        return decisions
