import json
import csv
import folium
from folium import plugins
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any

# --- 1. 颜色配置 (高对比度) ---
COLOR_MAP = {
    "D2D": "#0000FF",     # 【纯蓝】 D2D车辆
    "FIXED": "#FF0000",   # 【纯红】 固定车辆
    "REQ_WAIT": "#00FF00",    # 【纯绿】 乘客等待
    "REQ_ONBOARD": "#FFA500",  # 【橙色】 乘客上车
    "STOP": "#000000"         # 【纯黑】 站点
}


def load_json(path: Path) -> List[Dict]:
    if not path.exists():
        return []
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def create_square_geometry(lat: float, lon: float, size_meters: int = 30) -> Dict:
    offset = (size_meters / 111000) / 2
    coords = [[
        [lon - offset, lat - offset],
        [lon + offset, lat - offset],
        [lon + offset, lat + offset],
        [lon - offset, lat + offset],
        [lon - offset, lat - offset]
    ]]
    return {"type": "Polygon", "coordinates": coords}


def main():
    base_dir = Path(__file__).parent
    sim_file = base_dir / "sim_result.json"

    print(f"📂 读取数据: {sim_file}")
    sim_data = load_json(sim_file)
    if not sim_data:
        print("❌ 数据为空！")
        return

    # --- 修复时间轴：使用真实 ISO 时间字符串 ---
    # 假设仿真从早上 07:00:00 开始
    base_time = datetime(2024, 1, 1, 7, 0, 0)

    start_str = (
        base_time + timedelta(seconds=sim_data[0]["time"])).strftime("%H:%M:%S")
    end_str = (
        base_time + timedelta(seconds=sim_data[-1]["time"])).strftime("%H:%M:%S")

    print(f"⏱️ 仿真时间范围: {start_str} -> {end_str} (共 {len(sim_data)} 帧)")
    print("   (如果不止 2 分钟，但网页滑块很短，说明之前的解析错了。这次用 ISO 时间修复。)")

    # 准备地图
    start_lat, start_lon = 30.66, 104.07
    if sim_data and sim_data[0]["vehicles"]:
        start_lat = sim_data[0]["vehicles"][0]["lat"]
        start_lon = sim_data[0]["vehicles"][0]["lon"]

    m = folium.Map(location=[start_lat, start_lon],
                   zoom_start=14, tiles="CartoDB positron")

    # 绘制站点
    stops_file = base_dir / "config/minimal/stops.csv"
    if stops_file.exists():
        stops_layer = folium.FeatureGroup(name="Stops")
        try:
            with open(stops_file, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    lat = float(row.get("center_lat") or row.get("lat"))
                    lon = float(row.get("center_lon") or row.get("lon"))
                    folium.CircleMarker(
                        [lat, lon], radius=2, color=COLOR_MAP["STOP"], fill=True, opacity=1
                    ).add_to(stops_layer)
        except:
            pass
        stops_layer.add_to(m)

    # 生成动态帧
    features = []

    # 🔍 调试标记：是否已经检查过第一帧的颜色
    checked_first_frame = False

    for snapshot in sim_data:
        # 使用 ISO 时间字符串，解决“不到2分钟”的滑块 Bug
        current_dt = base_time + timedelta(seconds=snapshot["time"])
        time_str = current_dt.isoformat()

        # A. 车辆
        for v in snapshot["vehicles"]:
            vid = str(v['id']).lower()

            # --- 强制颜色逻辑 ---
            if "d2d" in vid:
                color = COLOR_MAP["D2D"]  # 蓝
                v_type = "D2D"
            else:
                color = COLOR_MAP["FIXED"]  # 红
                v_type = "Fixed"

            # 🔍 在第一帧强制打印写入 JSON 的颜色，自证清白
            if not checked_first_frame:
                print(f"🎨 [HTML写入检查] 车辆 {v['id']} ({v_type}) -> 写入颜色: {color}")

            features.append({
                "type": "Feature",
                "geometry": {
                    "type": "Point",
                    "coordinates": [v["lon"], v["lat"]],
                },
                "properties": {
                    "time": time_str,  # 使用字符串时间
                    "icon": "circle",
                    "iconstyle": {
                        "fillColor": color,
                        "fillOpacity": 1,
                        "stroke": "false",  # 字符串 false 有时比 boolean 更稳
                        "radius": 8 + (v.get("load", 0) * 2)
                    },
                    "popup": f"{v['id']} ({v_type})"
                }
            })

        if not checked_first_frame:
            checked_first_frame = True  # 只打印一次

        # B. 需求
        for r in snapshot["requests"]:
            status = r.get("status", "")
            if status in ["IN_VEHICLE", "COMPLETED", "CANCELLED", "RequestStatus.IN_VEHICLE", "RequestStatus.COMPLETED"]:
                continue

            color = COLOR_MAP["REQ_WAIT"] if "ASSIGNMENT" in status else COLOR_MAP["REQ_ONBOARD"]
            origin = r["origin"]
            lat = origin["lat"] if isinstance(origin, dict) else origin[0]
            lon = origin["lon"] if isinstance(origin, dict) else origin[1]

            features.append({
                "type": "Feature",
                "geometry": create_square_geometry(lat, lon),
                "properties": {
                    "time": time_str,
                    "style": {"color": color, "fillColor": color, "fillOpacity": 0.8, "weight": 1},
                    "popup": f"Req: {r['id']}"
                }
            })

    # 添加播放器
    plugins.TimestampedGeoJson(
        {"type": "FeatureCollection", "features": features},
        period="PT1S",
        duration="PT1S",
        add_last_point=False,
        auto_play=False,
        loop=False,
        max_speed=10,
        loop_button=True,
        date_options="HH:mm:ss",  # 显示具体的时分秒
        time_slider_drag_update=True
    ).add_to(m)

    folium.LayerControl().add_to(m)

    # 强制生成新文件
    out_file = "simulation_replay_final.html"
    out_path = base_dir / out_file
    m.save(str(out_path))

    print(f"\n🎉 最终版可视化已保存: {out_path}")
    print(f"👉 请务必打开文件: 【{out_file}】")
    print("   (如果还是红的，请右键网页->检查，或者换个浏览器，因为代码已经在这儿发誓它是蓝的了。)")


if __name__ == "__main__":
    main()
