"""
Utility functions used across the DRT simulation.

This module contains lightweight geographic helpers intended for fast
simulation prototyping. The distance calculation is intentionally simplified
and should be replaced with a Haversine implementation or a proper
geodesic library when higher accuracy is required.
"""

from typing import Tuple
import math


def calculate_distance(loc1: Tuple[float, float], loc2: Tuple[float, float]) -> float:
    """
    Estimate the planar distance between two geographic coordinates in meters.

    This function uses a simplified equirectangular approximation for speed.
    It is suitable for small distances and simulation prototypes but is not
    accurate for long distances or high-precision requirements. Replace with
    a Haversine or geodesic implementation for production use.

    Args:
        loc1: Tuple of (latitude, longitude) for the first point.
        loc2: Tuple of (latitude, longitude) for the second point.

    Returns:
        Estimated distance in meters between the two points.
    """
    # Note: lat/lon order is (lat, lon)
    # approximate meters per degree latitude
    lat_dist = (loc1[0] - loc2[0]) * 111111.0
    lon_dist = (loc1[1] - loc2[1]) * 111111.0 * math.cos(math.radians(loc1[0]))
    return math.sqrt(lat_dist**2 + lon_dist**2)


def move_towards(loc_start: Tuple[float, float], loc_end: Tuple[float, float], distance_m: float) -> Tuple[float, float]:
    """
    Move a point from loc_start toward loc_end by a given distance in meters.

    The function computes the straight-line direction (using the simplified
    distance approximation above) and returns the new coordinate after moving
    up to distance_m meters. If distance_m is greater than the separation
    between the points, the destination point is returned.

    Args:
        loc_start: Starting coordinate (latitude, longitude).
        loc_end: Destination coordinate (latitude, longitude).
        distance_m: Distance in meters to move from the start toward the end.

    Returns:
        New coordinate (latitude, longitude) after moving.
    """
    total_dist = calculate_distance(loc_start, loc_end)
    if total_dist <= 0:
        return loc_start

    ratio = distance_m / total_dist
    if ratio > 1.0:
        ratio = 1.0

    new_lat = loc_start[0] + (loc_end[0] - loc_start[0]) * ratio
    new_lon = loc_start[1] + (loc_end[1] - loc_start[1]) * ratio
    return (new_lat, new_lon)
